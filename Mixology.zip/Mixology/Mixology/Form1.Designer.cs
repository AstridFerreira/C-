﻿namespace Mixology
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cocktailsListBox = new System.Windows.Forms.ListBox();
            this.liquorShotListBox = new System.Windows.Forms.ListBox();
            this.SelectionGroupBox = new System.Windows.Forms.GroupBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.StockReportButton = new System.Windows.Forms.Button();
            this.AvailStockDisplayLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.DisplaySelectionListBox = new System.Windows.Forms.ListBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.QuantityLabel = new System.Windows.Forms.Label();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SloganLabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.AboutUsButton = new MetroFramework.Controls.MetroButton();
            this.AboutUsToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.DisplayToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ConfirmToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ManageInvToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ClearToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ExitToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.SelectionGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // cocktailsListBox
            // 
            this.cocktailsListBox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.cocktailsListBox.FormattingEnabled = true;
            this.cocktailsListBox.ItemHeight = 20;
            this.cocktailsListBox.Items.AddRange(new object[] {
            "Margarita\t\t€9.99",
            "Tequila Sunrise\t€8.99",
            "Cosmopolitan\t€9.99",
            "Mojito\t\t€7.99",
            "Bellini\t\t€8.99",
            "Jager Bomb\t€5.99",
            "Blue Lagoon\t€8.99",
            "Martini\t\t€9.99",
            "Pina Colada\t€7.99",
            "Manhattan\t€8.99",
            "Whiskey Sour\t€9.99",
            "Old Fashioned\t€8.99",
            "Black Russian\t€9.99",
            "Screwdriver\t€7.99",
            "Bloody Mary\t€8.99"});
            this.cocktailsListBox.Location = new System.Drawing.Point(20, 43);
            this.cocktailsListBox.Name = "cocktailsListBox";
            this.cocktailsListBox.Size = new System.Drawing.Size(329, 164);
            this.cocktailsListBox.TabIndex = 0;
            this.cocktailsListBox.SelectedIndexChanged += new System.EventHandler(this.cocktailsListBox_SelectedIndexChanged);
            // 
            // liquorShotListBox
            // 
            this.liquorShotListBox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.liquorShotListBox.FormattingEnabled = true;
            this.liquorShotListBox.ItemHeight = 20;
            this.liquorShotListBox.Items.AddRange(new object[] {
            "Pony Shot\t30ml\t+€0.99",
            "Jigger Shot\t45ml\t+€1.49",
            "Rocks Shot\t60ml\t+€1.79",
            "Double Shot\t90ml\t+€2.49"});
            this.liquorShotListBox.Location = new System.Drawing.Point(394, 43);
            this.liquorShotListBox.Name = "liquorShotListBox";
            this.liquorShotListBox.Size = new System.Drawing.Size(290, 164);
            this.liquorShotListBox.TabIndex = 1;
            this.liquorShotListBox.SelectedIndexChanged += new System.EventHandler(this.liquorShotListBox_SelectedIndexChanged);
            // 
            // SelectionGroupBox
            // 
            this.SelectionGroupBox.Controls.Add(this.ExitButton);
            this.SelectionGroupBox.Controls.Add(this.ClearButton);
            this.SelectionGroupBox.Controls.Add(this.StockReportButton);
            this.SelectionGroupBox.Controls.Add(this.AvailStockDisplayLabel);
            this.SelectionGroupBox.Controls.Add(this.label1);
            this.SelectionGroupBox.Controls.Add(this.ConfirmButton);
            this.SelectionGroupBox.Controls.Add(this.DisplaySelectionListBox);
            this.SelectionGroupBox.Controls.Add(this.displayButton);
            this.SelectionGroupBox.Controls.Add(this.QuantityLabel);
            this.SelectionGroupBox.Controls.Add(this.quantityTextBox);
            this.SelectionGroupBox.Controls.Add(this.cocktailsListBox);
            this.SelectionGroupBox.Controls.Add(this.liquorShotListBox);
            this.SelectionGroupBox.Location = new System.Drawing.Point(56, 145);
            this.SelectionGroupBox.Name = "SelectionGroupBox";
            this.SelectionGroupBox.Size = new System.Drawing.Size(1013, 404);
            this.SelectionGroupBox.TabIndex = 2;
            this.SelectionGroupBox.TabStop = false;
            this.SelectionGroupBox.Text = "Select Your Drinks";
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(793, 351);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(170, 36);
            this.ExitButton.TabIndex = 12;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(793, 311);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(170, 34);
            this.ClearButton.TabIndex = 11;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // StockReportButton
            // 
            this.StockReportButton.Location = new System.Drawing.Point(793, 258);
            this.StockReportButton.Name = "StockReportButton";
            this.StockReportButton.Size = new System.Drawing.Size(170, 47);
            this.StockReportButton.TabIndex = 10;
            this.StockReportButton.Text = "Manage Inventory";
            this.StockReportButton.UseVisualStyleBackColor = true;
            this.StockReportButton.Click += new System.EventHandler(this.StockReportButton_Click);
            // 
            // AvailStockDisplayLabel
            // 
            this.AvailStockDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AvailStockDisplayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvailStockDisplayLabel.Location = new System.Drawing.Point(854, 85);
            this.AvailStockDisplayLabel.Name = "AvailStockDisplayLabel";
            this.AvailStockDisplayLabel.Size = new System.Drawing.Size(100, 32);
            this.AvailStockDisplayLabel.TabIndex = 9;
            this.AvailStockDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(715, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Available Stock";
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(793, 209);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(170, 43);
            this.ConfirmButton.TabIndex = 7;
            this.ConfirmButton.Text = "Confirm Order";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // DisplaySelectionListBox
            // 
            this.DisplaySelectionListBox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.DisplaySelectionListBox.FormattingEnabled = true;
            this.DisplaySelectionListBox.ItemHeight = 20;
            this.DisplaySelectionListBox.Location = new System.Drawing.Point(20, 249);
            this.DisplaySelectionListBox.Name = "DisplaySelectionListBox";
            this.DisplaySelectionListBox.Size = new System.Drawing.Size(664, 124);
            this.DisplaySelectionListBox.TabIndex = 6;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(793, 160);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(170, 43);
            this.displayButton.TabIndex = 4;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.AutoSize = true;
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.Location = new System.Drawing.Point(756, 43);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.Size = new System.Drawing.Size(86, 20);
            this.QuantityLabel.TabIndex = 3;
            this.QuantityLabel.Text = "Quantity: ";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.quantityTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantityTextBox.Location = new System.Drawing.Point(854, 43);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(100, 26);
            this.quantityTextBox.TabIndex = 2;
            this.quantityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.quantityTextBox.TextChanged += new System.EventHandler(this.quantityTextBox_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(410, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(310, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // SloganLabel
            // 
            this.SloganLabel.AutoSize = true;
            this.SloganLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SloganLabel.Location = new System.Drawing.Point(263, 78);
            this.SloganLabel.Name = "SloganLabel";
            this.SloganLabel.Size = new System.Drawing.Size(635, 26);
            this.SloganLabel.TabIndex = 11;
            this.SloganLabel.Text = "One Cocktail.... Two Cocktails.... Three Cocktails.... Floor!!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(384, 567);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(315, 89);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // AboutUsButton
            // 
            this.AboutUsButton.BackColor = System.Drawing.Color.MediumAquamarine;
            this.AboutUsButton.Location = new System.Drawing.Point(935, 21);
            this.AboutUsButton.Name = "AboutUsButton";
            this.AboutUsButton.Size = new System.Drawing.Size(144, 32);
            this.AboutUsButton.TabIndex = 13;
            this.AboutUsButton.Text = "About Us";
            this.AboutUsButton.UseSelectable = true;
            this.AboutUsButton.Click += new System.EventHandler(this.AboutUsButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(1135, 668);
            this.Controls.Add(this.AboutUsButton);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.SloganLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.SelectionGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Welcome to Mixology";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SelectionGroupBox.ResumeLayout(false);
            this.SelectionGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox cocktailsListBox;
        private System.Windows.Forms.ListBox liquorShotListBox;
        private System.Windows.Forms.GroupBox SelectionGroupBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label QuantityLabel;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.ListBox DisplaySelectionListBox;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label AvailStockDisplayLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button StockReportButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Label SloganLabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button ExitButton;
        private MetroFramework.Controls.MetroButton AboutUsButton;
        private System.Windows.Forms.ToolTip AboutUsToolTip;
        private System.Windows.Forms.ToolTip DisplayToolTip;
        private System.Windows.Forms.ToolTip ConfirmToolTip;
        private System.Windows.Forms.ToolTip ManageInvToolTip;
        private System.Windows.Forms.ToolTip ClearToolTip;
        private System.Windows.Forms.ToolTip ExitToolTip;
    }
}

