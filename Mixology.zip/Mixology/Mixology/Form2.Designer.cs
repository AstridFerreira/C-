﻿namespace Mixology
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.StockReportListBox = new System.Windows.Forms.ListBox();
            this.CheckStockInventoryButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.SearchedIemsListbox = new System.Windows.Forms.ListBox();
            this.SearchNow = new System.Windows.Forms.Button();
            this.SearchTermTextBox = new System.Windows.Forms.TextBox();
            this.SearchbyTransRadio = new System.Windows.Forms.RadioButton();
            this.SearchbyDateRadio = new System.Windows.Forms.RadioButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.RestockInventoryButton = new System.Windows.Forms.Button();
            this.RestockInventory = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RestockQuantityTextbox = new System.Windows.Forms.TextBox();
            this.RestockButton = new System.Windows.Forms.Button();
            this.StockButton = new System.Windows.Forms.Button();
            this.RestockDisplayListBox = new System.Windows.Forms.ListBox();
            this.LiquorShotComboBox = new System.Windows.Forms.ComboBox();
            this.CocktailComboBox = new System.Windows.Forms.ComboBox();
            this.GenerateTrxReport = new System.Windows.Forms.Button();
            this.GenerateTransReportListbox = new System.Windows.Forms.ListBox();
            this.TransactionReport = new System.Windows.Forms.GroupBox();
            this.TransReportDownload = new System.Windows.Forms.Button();
            this.OpenTransTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.CheckStockTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.RestockTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.SearchNowTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.RestockInventoryTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.SearchTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.CheckInventoryTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.GenerateTransReportTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ExitButton = new System.Windows.Forms.Button();
            this.BackToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ExitToolTip = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SearchGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.RestockInventory.SuspendLayout();
            this.TransactionReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // StockReportListBox
            // 
            this.StockReportListBox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.StockReportListBox.FormattingEnabled = true;
            this.StockReportListBox.ItemHeight = 20;
            this.StockReportListBox.Location = new System.Drawing.Point(245, 281);
            this.StockReportListBox.Name = "StockReportListBox";
            this.StockReportListBox.Size = new System.Drawing.Size(746, 364);
            this.StockReportListBox.TabIndex = 0;
            // 
            // CheckStockInventoryButton
            // 
            this.CheckStockInventoryButton.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.CheckStockInventoryButton.FlatAppearance.BorderSize = 14;
            this.CheckStockInventoryButton.Location = new System.Drawing.Point(38, 463);
            this.CheckStockInventoryButton.Name = "CheckStockInventoryButton";
            this.CheckStockInventoryButton.Size = new System.Drawing.Size(122, 65);
            this.CheckStockInventoryButton.TabIndex = 1;
            this.CheckStockInventoryButton.Text = "Check Inventory";
            this.CheckStockInventoryButton.UseVisualStyleBackColor = true;
            this.CheckStockInventoryButton.Click += new System.EventHandler(this.CheckStockInventoryButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(458, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 57);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(271, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(635, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "One Cocktail.... Two Cocktails.... Three Cocktails.... Floor!!";
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(38, 344);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(122, 69);
            this.SearchButton.TabIndex = 4;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.Controls.Add(this.SearchedIemsListbox);
            this.SearchGroupBox.Controls.Add(this.SearchNow);
            this.SearchGroupBox.Controls.Add(this.SearchTermTextBox);
            this.SearchGroupBox.Controls.Add(this.SearchbyTransRadio);
            this.SearchGroupBox.Controls.Add(this.SearchbyDateRadio);
            this.SearchGroupBox.Location = new System.Drawing.Point(269, 255);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(671, 390);
            this.SearchGroupBox.TabIndex = 5;
            this.SearchGroupBox.TabStop = false;
            this.SearchGroupBox.Text = "Search";
            // 
            // SearchedIemsListbox
            // 
            this.SearchedIemsListbox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.SearchedIemsListbox.ForeColor = System.Drawing.Color.Black;
            this.SearchedIemsListbox.FormattingEnabled = true;
            this.SearchedIemsListbox.HorizontalScrollbar = true;
            this.SearchedIemsListbox.ItemHeight = 20;
            this.SearchedIemsListbox.Location = new System.Drawing.Point(7, 213);
            this.SearchedIemsListbox.Name = "SearchedIemsListbox";
            this.SearchedIemsListbox.ScrollAlwaysVisible = true;
            this.SearchedIemsListbox.Size = new System.Drawing.Size(612, 164);
            this.SearchedIemsListbox.TabIndex = 4;
            // 
            // SearchNow
            // 
            this.SearchNow.Location = new System.Drawing.Point(223, 110);
            this.SearchNow.Name = "SearchNow";
            this.SearchNow.Size = new System.Drawing.Size(138, 48);
            this.SearchNow.TabIndex = 3;
            this.SearchNow.Text = "Search Now";
            this.SearchNow.UseVisualStyleBackColor = true;
            this.SearchNow.Click += new System.EventHandler(this.SearchNow_Click);
            // 
            // SearchTermTextBox
            // 
            this.SearchTermTextBox.Location = new System.Drawing.Point(399, 24);
            this.SearchTermTextBox.Name = "SearchTermTextBox";
            this.SearchTermTextBox.Size = new System.Drawing.Size(138, 26);
            this.SearchTermTextBox.TabIndex = 2;
            // 
            // SearchbyTransRadio
            // 
            this.SearchbyTransRadio.AutoSize = true;
            this.SearchbyTransRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchbyTransRadio.Location = new System.Drawing.Point(48, 66);
            this.SearchbyTransRadio.Name = "SearchbyTransRadio";
            this.SearchbyTransRadio.Size = new System.Drawing.Size(175, 24);
            this.SearchbyTransRadio.TabIndex = 1;
            this.SearchbyTransRadio.TabStop = true;
            this.SearchbyTransRadio.Text = "Search by Trx No.";
            this.SearchbyTransRadio.UseVisualStyleBackColor = true;
            // 
            // SearchbyDateRadio
            // 
            this.SearchbyDateRadio.AutoSize = true;
            this.SearchbyDateRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchbyDateRadio.Location = new System.Drawing.Point(48, 26);
            this.SearchbyDateRadio.Name = "SearchbyDateRadio";
            this.SearchbyDateRadio.Size = new System.Drawing.Size(158, 24);
            this.SearchbyDateRadio.TabIndex = 0;
            this.SearchbyDateRadio.TabStop = true;
            this.SearchbyDateRadio.Text = "Search by Date";
            this.SearchbyDateRadio.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(398, 680);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(350, 99);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // RestockInventoryButton
            // 
            this.RestockInventoryButton.Location = new System.Drawing.Point(38, 227);
            this.RestockInventoryButton.Name = "RestockInventoryButton";
            this.RestockInventoryButton.Size = new System.Drawing.Size(122, 71);
            this.RestockInventoryButton.TabIndex = 7;
            this.RestockInventoryButton.Text = "Restock Inventory";
            this.RestockInventoryButton.UseVisualStyleBackColor = true;
            this.RestockInventoryButton.Click += new System.EventHandler(this.RestockInventoryButton_Click);
            // 
            // RestockInventory
            // 
            this.RestockInventory.Controls.Add(this.label2);
            this.RestockInventory.Controls.Add(this.RestockQuantityTextbox);
            this.RestockInventory.Controls.Add(this.RestockButton);
            this.RestockInventory.Controls.Add(this.StockButton);
            this.RestockInventory.Controls.Add(this.RestockDisplayListBox);
            this.RestockInventory.Controls.Add(this.LiquorShotComboBox);
            this.RestockInventory.Controls.Add(this.CocktailComboBox);
            this.RestockInventory.Location = new System.Drawing.Point(317, 200);
            this.RestockInventory.Name = "RestockInventory";
            this.RestockInventory.Size = new System.Drawing.Size(775, 488);
            this.RestockInventory.TabIndex = 8;
            this.RestockInventory.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(390, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Enter Restock Value:";
            // 
            // RestockQuantityTextbox
            // 
            this.RestockQuantityTextbox.Location = new System.Drawing.Point(576, 42);
            this.RestockQuantityTextbox.Name = "RestockQuantityTextbox";
            this.RestockQuantityTextbox.Size = new System.Drawing.Size(100, 26);
            this.RestockQuantityTextbox.TabIndex = 5;
            // 
            // RestockButton
            // 
            this.RestockButton.Location = new System.Drawing.Point(336, 89);
            this.RestockButton.Name = "RestockButton";
            this.RestockButton.Size = new System.Drawing.Size(119, 42);
            this.RestockButton.TabIndex = 4;
            this.RestockButton.Text = "Restock";
            this.RestockButton.UseVisualStyleBackColor = true;
            this.RestockButton.Click += new System.EventHandler(this.RestockButton_Click);
            // 
            // StockButton
            // 
            this.StockButton.Location = new System.Drawing.Point(136, 89);
            this.StockButton.Name = "StockButton";
            this.StockButton.Size = new System.Drawing.Size(128, 40);
            this.StockButton.TabIndex = 3;
            this.StockButton.Text = "Check Stock";
            this.StockButton.UseVisualStyleBackColor = true;
            this.StockButton.Click += new System.EventHandler(this.StockButton_Click);
            // 
            // RestockDisplayListBox
            // 
            this.RestockDisplayListBox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.RestockDisplayListBox.FormattingEnabled = true;
            this.RestockDisplayListBox.HorizontalScrollbar = true;
            this.RestockDisplayListBox.ItemHeight = 20;
            this.RestockDisplayListBox.Location = new System.Drawing.Point(32, 138);
            this.RestockDisplayListBox.Name = "RestockDisplayListBox";
            this.RestockDisplayListBox.ScrollAlwaysVisible = true;
            this.RestockDisplayListBox.Size = new System.Drawing.Size(644, 264);
            this.RestockDisplayListBox.TabIndex = 2;
            // 
            // LiquorShotComboBox
            // 
            this.LiquorShotComboBox.FormattingEnabled = true;
            this.LiquorShotComboBox.Items.AddRange(new object[] {
            "Pony Shot\t",
            "Jigger Shot\t",
            "Rocks Shot\t",
            "Double Shot\t"});
            this.LiquorShotComboBox.Location = new System.Drawing.Point(203, 38);
            this.LiquorShotComboBox.Name = "LiquorShotComboBox";
            this.LiquorShotComboBox.Size = new System.Drawing.Size(121, 28);
            this.LiquorShotComboBox.TabIndex = 1;
            this.LiquorShotComboBox.SelectedIndexChanged += new System.EventHandler(this.LiquorShotComboBox_SelectedIndexChanged);
            // 
            // CocktailComboBox
            // 
            this.CocktailComboBox.FormattingEnabled = true;
            this.CocktailComboBox.Items.AddRange(new object[] {
            "Margarita\t\t",
            "Tequila Sunrise\t",
            "Cosmopolitan\t",
            "Mojito\t\t",
            "Bellini\t\t",
            "Jager Bomb\t",
            "Blue Lagoon\t",
            "Martini\t\t",
            "Pina Colada\t",
            "Manhattan\t",
            "Whiskey Sour\t",
            "Old Fashioned\t",
            "Black Russian\t",
            "Screwdriver\t",
            "Bloody Mary\t"});
            this.CocktailComboBox.Location = new System.Drawing.Point(57, 38);
            this.CocktailComboBox.Name = "CocktailComboBox";
            this.CocktailComboBox.Size = new System.Drawing.Size(121, 28);
            this.CocktailComboBox.TabIndex = 0;
            this.CocktailComboBox.SelectedIndexChanged += new System.EventHandler(this.CocktailComboBox_SelectedIndexChanged);
            // 
            // GenerateTrxReport
            // 
            this.GenerateTrxReport.Location = new System.Drawing.Point(38, 569);
            this.GenerateTrxReport.Name = "GenerateTrxReport";
            this.GenerateTrxReport.Size = new System.Drawing.Size(122, 76);
            this.GenerateTrxReport.TabIndex = 9;
            this.GenerateTrxReport.Text = "Generate Transaction Report";
            this.GenerateTrxReport.UseVisualStyleBackColor = true;
            this.GenerateTrxReport.Click += new System.EventHandler(this.GenerateTrxReport_Click);
            // 
            // GenerateTransReportListbox
            // 
            this.GenerateTransReportListbox.BackColor = System.Drawing.Color.PaleTurquoise;
            this.GenerateTransReportListbox.FormattingEnabled = true;
            this.GenerateTransReportListbox.HorizontalScrollbar = true;
            this.GenerateTransReportListbox.ItemHeight = 20;
            this.GenerateTransReportListbox.Location = new System.Drawing.Point(6, 45);
            this.GenerateTransReportListbox.Name = "GenerateTransReportListbox";
            this.GenerateTransReportListbox.ScrollAlwaysVisible = true;
            this.GenerateTransReportListbox.Size = new System.Drawing.Size(682, 384);
            this.GenerateTransReportListbox.TabIndex = 10;
            // 
            // TransactionReport
            // 
            this.TransactionReport.Controls.Add(this.TransReportDownload);
            this.TransactionReport.Controls.Add(this.GenerateTransReportListbox);
            this.TransactionReport.Location = new System.Drawing.Point(359, 165);
            this.TransactionReport.Name = "TransactionReport";
            this.TransactionReport.Size = new System.Drawing.Size(683, 467);
            this.TransactionReport.TabIndex = 10;
            this.TransactionReport.TabStop = false;
            this.TransactionReport.Text = "Transaction Report";
            // 
            // TransReportDownload
            // 
            this.TransReportDownload.Location = new System.Drawing.Point(270, 455);
            this.TransReportDownload.Name = "TransReportDownload";
            this.TransReportDownload.Size = new System.Drawing.Size(211, 47);
            this.TransReportDownload.TabIndex = 11;
            this.TransReportDownload.Text = "Open Transaction Report";
            this.TransReportDownload.UseVisualStyleBackColor = true;
            this.TransReportDownload.Click += new System.EventHandler(this.TransReportDownload_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(38, 689);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(122, 43);
            this.ExitButton.TabIndex = 12;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(1221, 782);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.TransactionReport);
            this.Controls.Add(this.GenerateTrxReport);
            this.Controls.Add(this.RestockInventory);
            this.Controls.Add(this.RestockInventoryButton);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.CheckStockInventoryButton);
            this.Controls.Add(this.StockReportListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Manage Inventory -Mixology";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.SearchGroupBox.ResumeLayout(false);
            this.SearchGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.RestockInventory.ResumeLayout(false);
            this.RestockInventory.PerformLayout();
            this.TransactionReport.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox StockReportListBox;
        private System.Windows.Forms.Button CheckStockInventoryButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.GroupBox SearchGroupBox;
        private System.Windows.Forms.Button SearchNow;
        private System.Windows.Forms.TextBox SearchTermTextBox;
        private System.Windows.Forms.RadioButton SearchbyTransRadio;
        private System.Windows.Forms.RadioButton SearchbyDateRadio;
        private System.Windows.Forms.ListBox SearchedIemsListbox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button RestockInventoryButton;
        private System.Windows.Forms.GroupBox RestockInventory;
        private System.Windows.Forms.ComboBox LiquorShotComboBox;
        private System.Windows.Forms.ComboBox CocktailComboBox;
        private System.Windows.Forms.Button RestockButton;
        private System.Windows.Forms.Button StockButton;
        private System.Windows.Forms.ListBox RestockDisplayListBox;
        private System.Windows.Forms.TextBox RestockQuantityTextbox;
        private System.Windows.Forms.Button GenerateTrxReport;
        private System.Windows.Forms.ListBox GenerateTransReportListbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox TransactionReport;
        private System.Windows.Forms.Button TransReportDownload;
        private System.Windows.Forms.ToolTip OpenTransTooltip;
        private System.Windows.Forms.ToolTip CheckStockTooltip;
        private System.Windows.Forms.ToolTip RestockTooltip;
        private System.Windows.Forms.ToolTip SearchNowTooltip;
        private System.Windows.Forms.ToolTip RestockInventoryTooltip;
        private System.Windows.Forms.ToolTip SearchTooltip;
        private System.Windows.Forms.ToolTip CheckInventoryTooltip;
        private System.Windows.Forms.ToolTip GenerateTransReportTooltip;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.ToolTip BackToolTip;
        private System.Windows.Forms.ToolTip ExitToolTip;
    }
}