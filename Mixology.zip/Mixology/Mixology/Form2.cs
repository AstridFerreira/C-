﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Mixology
{
    public partial class Form2 : Form
    {
        const string TRANSACTIONLOGS = "Transactions.txt";
        const int ROWS = 15, COLS = 4;
        public Form2()
        {
            InitializeComponent();
            StockReportListBox.Visible = false;
            SearchGroupBox.Visible = false;
            GenerateTransReportListbox.Visible = false;
            RestockInventory.Visible = false;
            TransactionReport.Visible = false;

            //Setting up Access Keys
            RestockInventoryButton.Text = "&Restock Inventory";
            SearchButton.Text = "&Search";
            CheckStockInventoryButton.Text = "&Check Stock Inventory";
            GenerateTrxReport.Text = "&Generate Transaction Report";
            TransReportDownload.Text = "&Open Transaction Report";
            SearchNow.Text = "&Search Now";
            StockButton.Text = "&Check Stock";
            RestockButton.Text = "&Restock";
            ExitButton.Text = "&Exit";

            //Tooltips
            SearchNowTooltip.SetToolTip(SearchNow, "Search Now");
            RestockTooltip.SetToolTip(RestockButton, "Restock");
            SearchTooltip.SetToolTip(SearchButton,"Search");
            CheckInventoryTooltip.SetToolTip(CheckStockInventoryButton, "Check Inventory Stock");
            GenerateTransReportTooltip.SetToolTip(GenerateTrxReport, "Generate Transactions Report");
            OpenTransTooltip.SetToolTip(TransReportDownload, "Open Transaction Report");
            CheckStockTooltip.SetToolTip(StockButton,"Check Live Stock Count");
            ExitToolTip.SetToolTip(ExitButton, "Exit here");
        }
        /*
         Name: CheckStockInventoryButton_Click
         Description: This method displays the available stock in realtime.
         */
        private void CheckStockInventoryButton_Click(object sender, EventArgs e)
        {
            this.Text = "Live Stock Availabilty";
            StockReportListBox.Items.Clear();
            StockReportListBox.Items.Add("Stocks available at: " + DateTime.Now.ToString());
            StockReportListBox.Items.Add("");
            StockReportListBox.Items.Add("Cocktail \t Liquor Shot \t Available stock");
            StockReportListBox.Items.Add("");
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    StockReportListBox.Items.Add(Form1.COCKTAIL[i] + "\t" + Form1.LIQUORSHOT[j] + " \t " + Form1.Stock[i, j]);
                }
            }
            StockReportListBox.Visible = true;
            SearchGroupBox.Visible = false;
            TransactionReport.Visible = false;
            RestockInventory.Visible = false;
        }
        /*
         Name: Form2_Load
         Description: This methodis called on load of the form. A track of the live stock is kept.
         */
        private void Form2_Load(object sender, EventArgs e)
        {
            Form1.OpeningStock();
            Form1.ClosingStock();
        }
        /*
         Name: SearchNow_Click
         Description: This method conducts search based on transaction ID or Date.
         */
        private void SearchNow_Click(object sender, EventArgs e)
        {
            SearchedIemsListbox.Items.Clear();
            string SearchTerm = SearchTermTextBox.Text;
            if (!string.IsNullOrEmpty(SearchTermTextBox.Text))
            {
                if (SearchbyDateRadio.Checked == true)
                {
                    SearchByDate(SearchTermTextBox.Text);
                    SearchTermTextBox.Text = "";
                }
                else if (SearchbyTransRadio.Checked == true)
                {
                    SearchbyTransID(SearchTermTextBox.Text);
                    SearchTermTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("Please select the search option", "Selection required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please enter the search string", "Input required", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
        /*
         Name: SearchbyTransID
         Description: This method searches for all transactions based on the input transaction ID.
         */
        private string SearchbyTransID(string SearchTrans)
        {
            try
            {
                bool a = true;
                string SearchTerm = SearchTermTextBox.Text;
                string[] lines = System.IO.File.ReadAllLines(TRANSACTIONLOGS);

                foreach (string line in lines)
                {
                    string[] substring = line.Split(',');
                    if (substring[0].Equals("Transaction No: " +SearchTerm))
                    {
                        SearchedIemsListbox.Items.Add(line);
                        a = false;
                    }
                    SearchbyTransRadio.Checked = false;
                    
                }
                if (a == true)
                {
                    MessageBox.Show("No Transactions Found", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); SearchTermTextBox.Focus(); SearchTermTextBox.SelectAll();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return SearchTrans;
        }
        /*
         Name: SearchByDate
         Description: This method searches for all transactions based on the input date.
         */
        private void SearchByDate(string SearchDate)
        {
            bool a=true;
            try
            {
                string SearchTerm = SearchTermTextBox.Text;
                string[] lines = System.IO.File.ReadAllLines(TRANSACTIONLOGS);
                foreach (string line in lines)
                {
                    string[] substring = line.Split(',');

                    if (substring[1].Equals("Date:"+" "+SearchTerm))
                    {
                        SearchedIemsListbox.Items.Add(line);
                         a=false;
                    }
                }
                if (a == true)
                {
                    MessageBox.Show("Incorrect Input", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); SearchTermTextBox.Focus(); SearchTermTextBox.SelectAll();
                }
                SearchbyDateRadio.Checked = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        /*
         Name: SearchButton_Click
         Description: Triggered on click of the Search Button. Displays the different search types.
         */
        private void SearchButton_Click(object sender, EventArgs e)
        {
            this.Text = "Search";
            SearchGroupBox.Visible = true;
            StockReportListBox.Visible = false;
            TransactionReport.Visible = false;
            RestockInventory.Visible = false;
        }
        /*
         Name: RestockInventoryButton_Click
         Description: Triggered on click of the RestockInventoryButton Button. Displays the option to check live inventory count and restock the levels of items.
         */
        private void RestockInventoryButton_Click(object sender, EventArgs e)
        {
            this.Text = "Restock Inventory";
            RestockInventory.Visible = true;
            SearchGroupBox.Visible = false;
            StockReportListBox.Visible = false;
            TransactionReport.Visible = false;

        }
        /*
         Name: StockButton_Click
         Description: This method displays the live stock count of each item.
         */
        private void StockButton_Click(object sender, EventArgs e)
        {
            try
            {
                Form1.OpeningStock();
                RestockDisplayListBox.Items.Clear();
                RestockDisplayListBox.Items.Add("Available stocks at " + DateTime.Now.ToString());
                RestockDisplayListBox.Items.Add("");
                RestockDisplayListBox.Items.Add("Cocktail\t\t Liquor Shot\t\tAvailable Stock");
                RestockDisplayListBox.Items.Add("");
                for (int i = 0; i < ROWS; i++)
                {
                    for (int j = 0; j < COLS; j++)
                    {
                        RestockDisplayListBox.Items.Add(Form1.COCKTAIL[i] + "\t" + Form1.LIQUORSHOT[j] + " \t\t " + Form1.Stock[i, j]);//display the rows
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Form1.OpeningStock();
            RestockDisplayListBox.Items.Clear();
            RestockDisplayListBox.Items.Add("Available stocks at " + DateTime.Now.ToString());
            RestockDisplayListBox.Items.Add("");
            RestockDisplayListBox.Items.Add("Cocktail\t\t Liquor Shot\t\tAvailable Stock");
            RestockDisplayListBox.Items.Add("");
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    RestockDisplayListBox.Items.Add(Form1.COCKTAIL[i] + "\t" + Form1.LIQUORSHOT[j] + " \t\t " + Form1.Stock[i, j]);//display the rows
                }
            }
        }
        /*
         Name: RestockButton_Click
         Description: This method restocks the quantities based on selections. All exceptions are handled.
         */
        private void RestockButton_Click(object sender, EventArgs e)
        {
            if (CocktailComboBox.SelectedIndex != -1)
            {
                if (LiquorShotComboBox.SelectedIndex != -1)
                {
                    if (RestockQuantityTextbox.Text != "" && int.Parse(RestockQuantityTextbox.Text) > 0)
                    {
                        string RestockQuantity = RestockQuantityTextbox.Text;
                        int CocktailStock = CocktailComboBox.SelectedIndex;
                        int LiquorShotStock = LiquorShotComboBox.SelectedIndex;
                        Form1.Stock[CocktailStock, LiquorShotStock] = int.Parse(RestockQuantity.ToString());
                        Form1.ClosingStock();
                        StockButton.PerformClick();
                    }
                    else
                    {
                        MessageBox.Show("Quantity should be more than 0", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); RestockQuantityTextbox.Focus(); RestockQuantityTextbox.SelectAll();
                    }
                }
                else
                {
                    MessageBox.Show("A liquorshot selection is needed to proceed", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); LiquorShotComboBox.Focus();
                }
            }
            else
            {
                MessageBox.Show("A cocktail selection is needed to proceed", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); CocktailComboBox.Focus();
            }
            RestockQuantityTextbox.Text = "";
            
        }
        /*
         Name: GenerateTrxReport_Click
         Description: This method generates a report of all the transactions and orders made.
         */
        private void GenerateTrxReport_Click(object sender, EventArgs e)
        {
            this.Text = "Transaction Report";
            GenerateTransReportListbox.Items.Clear();
            GenerateTransReportListbox.Items.Add("Transactions until: " + DateTime.Now);
            string[] lines = File.ReadAllLines("Transactions.txt");
            
            foreach (string line in lines)
            {
                GenerateTransReportListbox.Items.Add(line);
            }
            GenerateTransReportListbox.Visible = true;
            RestockInventory.Visible = false;
            SearchGroupBox.Visible = false;
            StockReportListBox.Visible = false;
            TransactionReport.Visible = true;
        }
        /*
         Name: CocktailComboBox_SelectedIndexChanged
         Description: This method is triggered on the selected change of CocktailComboBox.
         */
        private void CocktailComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LiquorShotComboBox.Focus();
            LiquorShotComboBox.SelectAll();
        }
        /*
         Name: LiquorShotComboBox_SelectedIndexChanged
         Description: This method is triggered on the selected change of LiquorShotComboBox.
         */
        private void LiquorShotComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            RestockQuantityTextbox.Focus();
            RestockQuantityTextbox.SelectAll();
        }
        /*
         Name: ExitButton_Click
         Description: Application closes on click of the exit button.
         */
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*
         Name: TransReportDownload_Click
         Description: This method opens the text file where the transactions are stored.
         */
        private void TransReportDownload_Click(object sender, EventArgs e)
        {
            Process.Start("notepad.exe", "C:\\Users\\astri\\source\\repos\\Mixology\\Mixology\\bin\\Debug\\Transactions.txt");

        }
    }
}
