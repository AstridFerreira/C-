﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Mixology
{
    public partial class Form1 : Form
    {
        public static string[] COCKTAIL { get; private set; } = { "Margarita", "Tequila Sunrise", "Cosmopolitan", "Mojito", "Bellini", "Jager Bomb", "Blue Lagoon", "Martini", "Pina Colada", "Manhattan", "Whiskey Sour", "Old Fashioned", "Black Russian", "Screwdriver", "Bloody Mary" };
        public static string[] LIQUORSHOTPRICE { get; private set; } = { "0.99", "1.49", "1.79", "2.49" };
        public static string[] LIQUORSHOT { get; private set; } = { "Pony Shot", "Jigger Shot", "Rocks Shot", "Double Shot" };
        readonly static decimal[,] COST = { {10.98m, 11.48m, 11.78m, 12.48m},
                                            {9.98m, 10.48m, 10.78m, 11.48m},
                                            {10.98m, 11.48m, 11.78m, 12.48m},
                                            {8.98m, 9.48m, 9.78m, 10.48m},
                                            {9.98m, 10.48m, 10.78m, 11.48m},
                                            {6.98m, 7.48m, 7.78m, 8.48m},
                                            {9.98m, 10.48m, 10.78m, 11.48m},
                                            {10.98m, 11.48m, 11.78m, 12.48m},
                                            {8.98m, 9.48m, 9.78m, 10.48m},
                                            {9.98m, 10.48m, 10.78m, 11.48m},
                                            {10.98m, 11.48m, 11.78m, 12.48m},
                                            {9.98m, 10.48m, 10.78m, 11.48m},
                                            {10.98m, 11.48m, 11.78m, 12.48m},
                                            {8.98m, 9.48m, 9.78m, 10.48m},
                                            {9.98m, 10.48m, 10.78m, 11.48m}, };
        const string TRANSACTIONLOGS = "Transactions.txt", STOCKFILE = "StockLevel.txt";
        const int INCREMENT = 2, FORMWIDTH = 1000, FORMSTARTHEIGHT = 500, FORMEXPANDHEIGHT = 800;
        public static int[,] Stock  = new int[COCKTAIL.Length, LIQUORSHOT.Length];
        static int rows = COCKTAIL.Length, cols = LIQUORSHOT.Length; 
        int Quantity = 0, CocktailIndex = 0, LiquorShotIndex = 0;
        int totalQuantity, transactionNumber;
        decimal totalCost;
        string cocktailSelected, liquorShotPriceSelected,liquorShotSelected;

        StreamReader InputFile;
        StreamWriter OutputFile;
        public Form1()
        {
            InitializeComponent();
        }
        /*
         Name: ConfirmButton_Click
         Description: Triggers on Confirm Button being clicked. Details selected by users are processed.Stock is decreased and transactions are written into the file. Any exceptions raised are caught by the system.
         */
        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            this.Text = "User Confirmation";
            Boolean uniqueNumber = false;
            do
            {
                uniqueNumber = IsUnique(GenerateRandomNumber(), TRANSACTIONLOGS);
            }
            while (!uniqueNumber);
            string DisplayMessage = "Transaction number: " + transactionNumber + "\t";
            foreach (var item in DisplaySelectionListBox.Items.OfType<string>().ToList())
            {
                DisplayMessage = DisplayMessage + item + "\t" + "Total Cost: " + totalCost.ToString("C") + '\t' + "Total Quantity: " + totalQuantity.ToString() + '\t';

            }
            string Message = DisplayMessage + "\nDo you wish to confirm the order?";
            DialogResult Result = MessageBox.Show(Message, "Confirm Order", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                
                Stock[CocktailIndex, LiquorShotIndex] -= Quantity;
                OutputFile = File.AppendText(TRANSACTIONLOGS);
                OutputFile.Write("\n" + "Transaction No: " +transactionNumber + ",");
                OutputFile.Write("Date: " + DateTime.Now.ToShortDateString() + ",");
                foreach (var item in DisplaySelectionListBox.Items.OfType<string>().ToList())
                {
                    OutputFile.Write((item).ToString() + "\t");
                    ClosingStock();

                }
                OutputFile.Write("," + "Total Cost: " + totalCost.ToString("c"));
                OutputFile.Write(","+ "Total Quantity: " + totalQuantity.ToString());
                OutputFile.Close();
                ClearButton.PerformClick();
            }
            else
            {
                ClearButton.PerformClick();
            }
            //Form Expansion
            for (int i = FORMSTARTHEIGHT; i < FORMEXPANDHEIGHT; i += INCREMENT)
            {
                this.Size = new Size(FORMWIDTH, i);
                this.Update();
                System.Threading.Thread.Sleep(1);
            }
            displayButton.Enabled = false;
            
        }
        /*
         Name: GenerateRandomNumber
         Description: Generating a Random value generated for Transaction ID.
         */
        private string GenerateRandomNumber()
        {
            Random rand = new Random();
            transactionNumber = rand.Next(10000,99999);
            return transactionNumber.ToString();
        }
        /*
         Name: IsUnique
         Description: Validating the uniqueness of the Random value generated for Transaction ID.
         */
        private Boolean IsUnique(string searchString, string filename)
        {
            int transactionLength = DisplaySelectionListBox.Items.Count;
            try
            {
                InputFile = File.OpenText(TRANSACTIONLOGS);
                while (!InputFile.EndOfStream)
                    if (searchString.Equals(InputFile.ReadLine()))
                    {
                        InputFile.Close();
                        return false;
                    }
                for (int i=0; i < transactionLength - 1; i++)
                {
                    InputFile.ReadLine();
                }
                InputFile.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                InputFile.Close();
                return true;
            }
            
        }
        /*
        Name: ExitButton_Click
        Description: Application exits on click of this button.
        */
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /*
        Name: AboutUsButton_Click
        Description: Displays the client profile of the company.
        */
        private void AboutUsButton_Click(object sender, EventArgs e)
        {
            MetroFramework.MetroMessageBox.Show(this, "\nMixology Cocktails are hand mixed and bottled at our custom built cocktail factory in Dublin. Made By Bartenders, Not by Pretenders, our cocktails are made with 100% natural ingredients, premium spirits and some serious bartender know-how. Since launching in October 2020, Mixology Cocktails has been awarded Best Drinks at the Irish Made Awards 2021, and is the winner of the inaugural Innovator of the Year award at the Food & Wine Awards 2021.The team at BAR 1661, winner of Ireland’s Best Cocktail Bar 2019, have poured their expertise and passion for crafting exceptional drinks into this range of high quality bottled cocktails, now available at over 40 venues around Ireland and delivered to your door nationwide.", "MIXOLOGY", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CheckAvailabilityButton_Click(object sender, EventArgs e)
        {
            AvailStockDisplayLabel.Text = Stock[CocktailIndex, LiquorShotIndex].ToString();
        }
        
        /*
        Name: StockReportButton_Click
        Description: This takes you to the second form for managing reports and inventory.
        */
        private void StockReportButton_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }
        /*
         Name: liquorShotListBox_SelectedIndexChanged
         Description:Quantity Textbox is on focus after a selection is made in liquorShotListBox
         */
        private void liquorShotListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            quantityTextBox.Focus();
            quantityTextBox.SelectAll();
        }
        /*
         Name: ClearAll
         Description: Triggers on Clear Button being clicked. All controls are cleared.
         */
        private void ClearAll(Control.ControlCollection Clear)
        {
            foreach (Control c in Clear)
            {
                if (c.HasChildren)
                {
                    ClearAll(c.Controls);
                }
                else if (c is TextBox)
                {
                    c.Text = "";
                }
            }
        }
        /*
        Name: ClearButton_Click
        Description: This method is called on clicking the clear button. All controls are cleared along with textbox inputs and selections.
        */
        private void ClearButton_Click(object sender, EventArgs e)
        {
            this.Text = "Welcome to Mixology";
            ClearAll((Control.ControlCollection)this.Controls);
            quantityTextBox.Text = "";
            AvailStockDisplayLabel.Text = "";
            cocktailsListBox.SelectedItems.Clear();
            liquorShotListBox.SelectedItems.Clear();
            DisplaySelectionListBox.Items.Clear();
            DisplaySelectionListBox.Visible = false;
            ConfirmButton.Enabled = false;
            displayButton.Enabled = false;
            //Form Reduction
            for (int i = FORMEXPANDHEIGHT; i > FORMSTARTHEIGHT; i -= INCREMENT)
            {
                this.Size = new Size(FORMWIDTH, i);
                this.Update();
                System.Threading.Thread.Sleep(1);
            }
        }
        /*
        Name: Form1_Load
        Description: Runs on load of the form.
        */
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Welcome to Mixology";
            OpeningStock();
            DisplaySelectionListBox.Visible = false;
            displayButton.Enabled = false;
            ConfirmButton.Enabled = false;

            // Setting up Access Keys
            AboutUsButton.Text = "&About Us";
            displayButton.Text = "&Display";
            ConfirmButton.Text = "&Confirm Order";
            StockReportButton.Text = "&Manage Inventory";
            ClearButton.Text = "&Clear";
            ExitButton.Text = "&Exit";
            //Tooltips
            AboutUsToolTip.SetToolTip(AboutUsButton, "About Us");
            DisplayToolTip.SetToolTip(displayButton, "Display Details");
            ConfirmToolTip.SetToolTip(ConfirmButton, "Confirm your order");
            ManageInvToolTip.SetToolTip(StockReportButton, "Manage Inventory and Reports");
            ClearToolTip.SetToolTip(ClearButton, "Clear");
            ExitToolTip.SetToolTip(ExitButton, "Exit here");
        }
        /*
        Name: quantityTextBox_TextChanged
        Description: Triggers on the text change event of quantityTextBox
        */
        private void quantityTextBox_TextChanged(object sender, EventArgs e)
        {
            displayButton.Enabled = true;
            displayButton.Focus();
            AvailStockDisplayLabel.Text = Stock[CocktailIndex, LiquorShotIndex].ToString();
        }
        /*
        Name: cocktailsListBox_SelectedIndexChanged
        Description: Triggers on the text change event of cocktailsListBox
        */
        private void cocktailsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            liquorShotListBox.Focus();
        }
        /*
         Name: DisplayButton_Click
         Description: Triggers on Display Button being clicked. Details selected by customers are processed. Any exceptions raised are caught by the system.
         */
        private void displayButton_Click(object sender, EventArgs e)
        {
            this.Text = "Order Details";
            decimal Price = 0;
            totalQuantity = 0;
            totalCost = 0;
            
            if (quantityTextBox.Text != " ")
            {
                if (int.TryParse(quantityTextBox.Text, out Quantity))
                {
                    if (Quantity>0)
                    {
                        if (cocktailsListBox.SelectedIndex != -1)
                     {
                            if (liquorShotListBox.SelectedIndex != -1)
                            {
                               
                                CocktailIndex = cocktailsListBox.SelectedIndex;
                                LiquorShotIndex = liquorShotListBox.SelectedIndex;
                                if (Stock[CocktailIndex, LiquorShotIndex] >= Quantity)
                                {
                                    cocktailSelected = COCKTAIL[CocktailIndex];
                                    liquorShotPriceSelected = LIQUORSHOTPRICE[LiquorShotIndex];
                                    liquorShotSelected = LIQUORSHOT[LiquorShotIndex];
                                    Price = ((COST[CocktailIndex, LiquorShotIndex]) * Quantity);
                                    DisplaySelectionListBox.Items.Add(cocktailSelected.ToString()  + "-" + liquorShotSelected.ToString() + "-" + Quantity.ToString() + " drink(s)" + "-" + Price.ToString("c") );
                                    totalCost += (COST[CocktailIndex, LiquorShotIndex]);
                                    totalQuantity += Quantity;
                                    AvailStockDisplayLabel.Text = Stock[CocktailIndex, LiquorShotIndex].ToString();
                                    DisplaySelectionListBox.Visible = true;
                                    ConfirmButton.Enabled = true;
                                    ConfirmButton.Focus();
                                    quantityTextBox.Text = "";
                                }
                                else
                                {
                                    MessageBox.Show("Quantity cannot be more than the stock available", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); quantityTextBox.Focus(); quantityTextBox.SelectAll();
                                }
                            }
                            else
                            {
                                MessageBox.Show("A shot quantity is needed to proceed", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); liquorShotListBox.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Cocktail selection is needed to proceed", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); cocktailsListBox.Focus();
                        }
                    }
                    else { MessageBox.Show("Quantity needs to be greater than 0", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); quantityTextBox.Focus(); quantityTextBox.SelectAll(); }
                }
                else { MessageBox.Show("Entry of numerical whole number required", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); quantityTextBox.Focus(); quantityTextBox.SelectAll(); }
            }
            else { MessageBox.Show("Numerical whole number of Quantity required", "Entry Error", MessageBoxButtons.OK, MessageBoxIcon.Error); quantityTextBox.Focus(); quantityTextBox.SelectAll(); }
        }
        /*
         Name: ClosingStock
         Description: This method is called on application closing and while writing into the transaction file.
         */
        public static void ClosingStock()
        {
            try
            {
                StreamWriter OutputFile = new StreamWriter(STOCKFILE);
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < cols; j++)
                    {
                        OutputFile.WriteLine(Stock[i, j]);
                    }
                }
                OutputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /*
         Name: OpeningStock
         Description: This method is called on application opening and while read from the transaction file.
         */
        public static void OpeningStock()
        {
            try
            {
                StreamReader InputFile = new StreamReader(STOCKFILE);
                while (!InputFile.EndOfStream)
                {
                    for (int i = 0; i < rows; i++)
                    {
                        for (int j = 0; j < cols; j++)
                        {
                            Stock[i, j] = int.Parse(InputFile.ReadLine());
                        }
                    }
                }

                InputFile.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
