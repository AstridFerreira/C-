﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Invest4u
{
    public partial class Form1 : Form
    {
        //Constant Values Declarations and Global Variables Initializations
        const string PASSWORD = "ShowMeTheMoney#";
        const decimal INTERESTUPTO1 = 0.005000m, INTERESTUPTO2 = 0.006250m, INTERESTUPTO3 = 0.007125m, INTERESTUPTO4 = 0.011250m;
        const decimal INTERESTMORETHAN1 = 0.006000m, INTERESTMORETHAN2 = 0.007250m, INTERESTMORETHAN3 = 0.008125m, INTERESTMORETHAN4 = 0.012500m;
        decimal FutureValue1, FutureValue2, FutureValue3, FutureValue4, FutureValue5, FutureValue6, FutureValue7, FutureValue8;
        const int TERM1 = 1, TERM3 = 3, TERM5 = 5, TERM10 = 10;
        int MaxAttempts = 4, PasswordCounter = -1;
        const string FILENAME = "TransactionLogs.txt";
        decimal InvestmentAmount, InterestApplied, InterestAccured, TotalInterestAccrued;
        int TransactionLength = 10, TransactionID, TotalTerm, TermSelected;
        StreamWriter Ofile;
        StreamReader Ifile;
        decimal CompoundInterest, TotalInvestmentAmount;
        int TransCount = 0;
        const int BONUS = 25000;
        string FirstName, LastName, TelephoneNo, EmailID, TransactionDate;
        const int INCREMENT = 2, FORMWIDTH = 1000, FORMSTARTHEIGHT = 500, FORMEXPANDHEIGHT = 800;


        private void InvestmentAmounttTextBox_TextChanged(object sender, EventArgs e)
        {
            DisplayButton.Enabled = true;
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchGroupBox.Visible = true;
            DisplayGroupBox.Visible = false;
            ProceedGroupBoxDetails.Visible = false;
            SummaryGroupBox.Visible = false;
            Proceed.Enabled = false;
            SubmitButton.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PasswordTextBox.Focus();
            InvestmentAmountLabel.Visible = false;
            InvestmentAmounttTextBox.Visible = false;
            ButtonGroupBox.Visible = false;
            SearchGroupBox.Visible = false;
            DisplayGroupBox.Visible = false;
            ProceedGroupBoxDetails.Visible = false;
            SummaryGroupBox.Visible = false;
            LoginGroupBox.Visible = true;
            this.Size = new Size(FORMWIDTH, FORMSTARTHEIGHT);
        }

        private void FirstNTextbox_TextChanged(object sender, EventArgs e)
        {
            SubmitButton.Enabled = true;
        }

        private void EmailTextbox_TextChanged(object sender, EventArgs e)
        {
            SubmitButton.Enabled = true;
        }

        private void LastNTextbox_TextChanged(object sender, EventArgs e)
        {
            SubmitButton.Enabled = true;
        }

        private void TeleTextbox_TextChanged(object sender, EventArgs e)
        {
            SubmitButton.Enabled = true;
        }
        /*
         Name: ExitButton_Click
         Description: This method is called on clicking the Exit button. Application is exited.
         */
        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /*
         Name: ClearButton_Click
         Description: This method is called on clicking the clear button. All controls are cleared along with textbox inputs and selections.
         */
        public void ClearButton_Click(object sender, EventArgs e)
        {
            this.Text = "Welcome to Invest4u";
            ClearAll((Control.ControlCollection)this.Controls);
            OneYearRadioButton.Checked = false;
            ThreeYearRadioButton.Checked = false;
            FiveYearsRadioButton.Checked = false;
            TenYearRadioButton.Checked = false;
            DisplayGroupBox.Visible = false;
            SummaryGroupBox.Visible = false;
            SearchGroupBox.Visible = false;
            ProceedGroupBoxDetails.Visible = false;
            FirstNTextbox.Clear();
            LastNTextbox.Clear();
            EmailTextbox.Clear();
            TeleTextbox.Clear();
            SummaryListBox.Items.Clear();
            SearchListBox.Items.Clear();
            SearchByDateTextBox.Clear();
            //Form Reduction
            for (int i = FORMEXPANDHEIGHT; i > FORMSTARTHEIGHT; i -= INCREMENT)
            {
                this.Size = new Size(FORMWIDTH, i);
                this.Update();
                System.Threading.Thread.Sleep(1);
            }
        }
        /*
         Name: ClearAll
         Description: Triggers on Clear Button being clicked. All controls are cleared.
         */
        private void ClearAll(Control.ControlCollection Clear)
        {
            foreach (Control c in Clear)
            {
                if (c.HasChildren)
                {
                    ClearAll(c.Controls);
                }
                else if (c is TextBox)
                {
                    c.Text = "";
                }
            }
        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {
            PasswordTextBox.PasswordChar = '●';
            Login.Enabled = true;
        }

        private void TenYearRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Proceed.Enabled = true;
            ProceedGroupBox.Enabled = true;
        }

        private void FiveYearsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Proceed.Enabled = true;
            ProceedGroupBox.Enabled = true;
        }

        private void ThreeYearRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Proceed.Enabled = true;
            ProceedGroupBox.Enabled = true;
        }

        private void OneYearRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            Proceed.Enabled = true;
            ProceedGroupBox.Enabled = true;
        }

        public Form1()
        {
            InitializeComponent();
            //Setting up Access Keys
            Login.Text = "&Login";
            DisplayButton.Text = "&Display";
            Proceed.Text = "&Proceed";
            SubmitButton.Text = "&Submit";
            SummaryButton.Text = "&Summary";
            SearchButton.Text = "&Search";
            ClearButton.Text = "&Clear";
            ExitButton.Text = "&Exit";

            //Creating ToolTips
            ExitToolTip.SetToolTip(ExitButton, "Exit Here");
            ClearToolTip.SetToolTip(ClearButton, "Clear All");
            LoginToolTip.SetToolTip(Login, "Login here");
            SummaryToolTip.SetToolTip(SummaryButton, "Summary of Transactions");
            SearchToolTip.SetToolTip(SearchButton, "Search Transactions");
            DisplayToolTip.SetToolTip(DisplayButton, "Display Details");
            ProceedToolTip.SetToolTip(Proceed, "Proceed");
            SubmitToolTip.SetToolTip(SubmitButton, "Submit Details");
        }
        /*
         Name: Login_Click
         Description: Triggers on Form Load. Login details by investors are validated. Any exceptions raised are caught by the system.
         */
        private void Login_Click(object sender, EventArgs e)
        {
            PasswordCounter++;
            try
            {
                if (PasswordTextBox.Text == PASSWORD)
                {
                    //MessageBox.Show("Login Successful", "Login");
                    InvestmentAmountLabel.Visible = true;
                    InvestmentAmounttTextBox.Visible = true;
                    InvestmentAmounttTextBox.Focus();
                    ButtonGroupBox.Visible = true;
                    Proceed.Enabled = false;
                    SubmitButton.Enabled = false;
                    SummaryButton.Enabled = true;
                    SearchButton.Enabled = true;
                    LoginGroupBox.Visible = false;

                }
                else if (PasswordCounter <= MaxAttempts)
                {
                    //Displaying Warning for Incorrect Password
                    MaxAttempts--;
                    MessageBox.Show("You have " + MaxAttempts + "  attempts left", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    PasswordTextBox.Clear();
                    PasswordTextBox.Focus();
                    PasswordTextBox.SelectAll();
                }
                else
                {
                    //Application exits on the 4th incorect attempt
                    MessageBox.Show("You have exhausted the maximum number of attempts", "Please Login", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    Application.Exit();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter the password", "Password required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /*
         Name: DisplayButton_Click
         Description: Triggers on Display Button being clicked. Details selected by investors are processed. Any exceptions raised are caught by the system.
         */
        public void DisplayButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.Text = "Display Details";
                InvestmentAmount = decimal.Parse(InvestmentAmounttTextBox.Text);
                RadioSelect();
                DisplayGroupBox.Visible = true;
                SummaryGroupBox.Visible = false;
                SearchGroupBox.Visible = false;
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter the correct numerical invest amount", "Amount required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        /*
         Name: RadioSelect
         Description: Triggers on Display Button being clicked. Captures the Term duration, Investamount Amount selected and the interest applied on it.
         */
        private void RadioSelect()
        {
            if (InvestmentAmount <= 100000)
            {
                FutureValue1 = CalculateCompoundInterest(TERM1, InvestmentAmount, INTERESTUPTO1);
                TermOneLabel.Text = FutureValue1.ToString("c");
                FutureValue2 = CalculateCompoundInterest(TERM3, InvestmentAmount, INTERESTUPTO3);
                TermThreeLabel.Text = FutureValue2.ToString("c");
                FutureValue3 = CalculateCompoundInterest(TERM5, InvestmentAmount, INTERESTUPTO3);
                TermFiveLabel.Text = FutureValue3.ToString("c");
                FutureValue4 = CalculateCompoundInterest(TERM10, InvestmentAmount, INTERESTUPTO4);
                TermTenLabel.Text = FutureValue4.ToString("c");
            }
            else if (InvestmentAmount > 100000 && InvestmentAmount <= 1000000)
            {
                FutureValue5 = CalculateCompoundInterest(TERM1, InvestmentAmount, INTERESTMORETHAN1);
                TermOneLabel.Text = FutureValue5.ToString("c");
                FutureValue6 = CalculateCompoundInterest(TERM3, InvestmentAmount, INTERESTMORETHAN2);
                TermThreeLabel.Text = FutureValue6.ToString("c");
                FutureValue7 = CalculateCompoundInterest(TERM5, InvestmentAmount, INTERESTMORETHAN3);
                TermFiveLabel.Text = FutureValue7.ToString("c");
                FutureValue8 = CalculateCompoundInterest(TERM10, InvestmentAmount, INTERESTMORETHAN4);
                TermTenLabel.Text = FutureValue8.ToString("c");
            }
            else if (InvestmentAmount > 1000000)
            {
                FutureValue5 = CalculateCompoundInterest(TERM1, InvestmentAmount, INTERESTMORETHAN1);
                TermOneLabel.Text = FutureValue5.ToString("c");
                FutureValue6 = CalculateCompoundInterest(TERM3, InvestmentAmount, INTERESTMORETHAN2);
                TermThreeLabel.Text = FutureValue6.ToString("c");
                FutureValue7 = CalculateCompoundInterest(TERM5, InvestmentAmount, INTERESTMORETHAN3) + BONUS;
                TermFiveLabel.Text = FutureValue7.ToString("c");
                FutureValue8 = CalculateCompoundInterest(TERM10, InvestmentAmount, INTERESTMORETHAN4) + BONUS;
                TermTenLabel.Text = FutureValue8.ToString("c");
            }
        }
        /*
         Name: Proceed_Click
         Description: Triggers on Proceed Button being clicked. Details selected by investors are processed.Calculations are made and user input for personal details are taken. Any exceptions raised are caught by the system.
         */
        private void Proceed_Click(object sender, EventArgs e)
        {
            this.Text = "Proceed with your investment";
            if (OneYearRadioButton.Checked == true || ThreeYearRadioButton.Checked == true || FiveYearsRadioButton.Checked == true || TenYearRadioButton.Checked == true)
            {
                TransID.Text = GenerateTransactionID(TransactionID).ToString();
                DateTime date = DateTime.Now;
                TransactionDate = date.ToShortDateString();
                CurrentDateDisplayLabel.Text = TransactionDate;
                if ((OneYearRadioButton.Checked == true) && (InvestmentAmount <= 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue1.ToString("c");
                    TermSelected = TERM1;
                    InterestApplied = INTERESTUPTO1;
                    InterestAccured = FutureValue1 - InvestmentAmount;
                }
                else if ((OneYearRadioButton.Checked == true) && (InvestmentAmount > 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue5.ToString("c");
                    TermSelected = TERM1;
                    InterestApplied = INTERESTMORETHAN1;
                    InterestAccured = FutureValue5 - InvestmentAmount;
                }
                else if ((ThreeYearRadioButton.Checked == true) && (InvestmentAmount <= 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue2.ToString("c");
                    TermSelected = TERM3;
                    InterestApplied = INTERESTUPTO2;
                    InterestAccured = FutureValue2 - InvestmentAmount;
                }
                else if ((ThreeYearRadioButton.Checked == true) && (InvestmentAmount > 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue6.ToString("c");
                    TermSelected = TERM3;
                    InterestApplied = INTERESTMORETHAN2;
                    InterestAccured = FutureValue6 - InvestmentAmount;
                }
                if ((FiveYearsRadioButton.Checked == true) && (InvestmentAmount <= 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue3.ToString("c");
                    TermSelected = TERM5;
                    InterestApplied = INTERESTUPTO3;
                    InterestAccured = FutureValue3 - InvestmentAmount;
                }
                else if ((FiveYearsRadioButton.Checked == true) && (InvestmentAmount > 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue7.ToString("c");
                    TermSelected = TERM5;
                    InterestApplied = INTERESTMORETHAN3;
                    InterestAccured = FutureValue7 - InvestmentAmount;
                }
                else if ((TenYearRadioButton.Checked == true) && (InvestmentAmount <= 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue4.ToString("c");
                    TermSelected = TERM10;
                    InterestApplied = INTERESTUPTO4;
                    InterestAccured = FutureValue4 - InvestmentAmount;
                }
                else if ((TenYearRadioButton.Checked == true) && (InvestmentAmount > 100000))
                {
                    InvestmentFutureValueDisplayLabel.Text = FutureValue8.ToString("c");
                    TermSelected = TERM10;
                    InterestApplied = INTERESTMORETHAN4;
                    InterestAccured = FutureValue8 - InvestmentAmount;
                }
                DisplayGroupBox.Visible = false;
                ProceedGroupBoxDetails.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select the Tenure", "Term Duration required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /*
         Name: CalculateCompoundInterest
         Description: Calculations for Compount Interest is done here. 
         */
        public decimal CalculateCompoundInterest(int Term, decimal Principal, decimal Interest)
        {
            decimal body = 1 + (Interest / 100);
            decimal exp = 12 * Term;
            for (int i = 0; i <= Term; i++)
            {
                CompoundInterest = Principal * (decimal)Math.Pow((double)body, (double)exp);
            }
            return CompoundInterest;//returning Calculate Compound Interest 
        }
        /*
         Name: GenerateTransactionID
         Description: Unique Random Value Generation takes place here. 
         */
        public int GenerateTransactionID(int RandomNo)
        {
            Boolean UniqueRandomNumber;
            do
            {
                UniqueRandomNumber = IsUnique(TransactionID.ToString(), FILENAME);
                Random rand = new Random();
                TransactionID = rand.Next(10000000, 99999999);
                return TransactionID;
            } while (!UniqueRandomNumber);

        }
        /*
         Name: SubmitButton_Click
         Description: User Details entered are stored in a text file along with all the details on the investments.
         */
        public void SubmitButton_Click(object sender, EventArgs e)
        {
            this.Text = "Submit Details into the File";
            try
            {
                string NewLine = Environment.NewLine;
                //if (!string.IsNullOrEmpty(FirstNTextbox.Text))
                FirstName = FirstNTextbox.Text;
                LastName = LastNTextbox.Text;
                TelephoneNo = TeleTextbox.Text;
                EmailID = EmailTextbox.Text;
                if (FirstName == "" || LastName == "" || TelephoneNo == "" || EmailID == "")
                {
                    MessageBox.Show("Please fill in the details required", "Input Details required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }
                else if (FirstName != null && LastName != null && TelephoneNo != null && EmailID != null)
                {
                    DialogResult ProceedConfirm = MessageBox.Show("Here are your details" + NewLine + "Transaction ID: " + TransactionID.ToString() + " Date: " + TransactionDate.ToString() + " First Name: " + FirstName + " Last Name: " + LastName + " Email ID: " + EmailID + " Telephone No: " + TelephoneNo + " Investment Future Value: " + InvestmentFutureValueDisplayLabel.Text + " Term: " + TermSelected + "years " + " Interest Accured: " + InterestAccured.ToString("c"), "Investment Details", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (ProceedConfirm == DialogResult.Yes)
                    {
                        MessageBox.Show("Do you wish to proceed with the investment?", "Final Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Question);

                        Ofile = File.AppendText(FILENAME);
                        Ofile.WriteLine(TransactionID.ToString());
                        Ofile.WriteLine(TransactionDate.ToString());
                        Ofile.WriteLine(InvestmentFutureValueDisplayLabel.Text.ToString());
                        Ofile.WriteLine(InvestmentAmount);
                        Ofile.WriteLine(FirstName);
                        Ofile.WriteLine(LastName);
                        Ofile.WriteLine(EmailID);
                        Ofile.WriteLine(TelephoneNo);
                        Ofile.WriteLine(TermSelected);
                        Ofile.WriteLine(InterestAccured.ToString("F"));
                        Ofile.Close();
                        ProceedGroupBoxDetails.Visible = false;
                    }
                    else if (ProceedConfirm == DialogResult.No)
                    {
                        ClearButton.PerformClick();
                        SubmitButton.Enabled = false;
                    }

                    SummaryButton.Enabled = true;
                    SearchButton.Enabled = true;
                    Proceed.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message);
            }
            finally
            {
                if (Ifile != null)
                {
                    Ifile.Dispose(); // dispose the StreamReader if it's not null
                }
            }
        }
        /*
         Name: IsUnique
         Description: Validating the uniqueness of the Random value generated for Transaction ID.
         */
        public Boolean IsUnique(string TransactionID, string Filename)
        {
            try
            {
                Ifile = File.OpenText(FILENAME);
                while (!Ifile.EndOfStream)
                {
                    if (TransactionID.Equals(Ifile.ReadLine()))
                    {
                        Ifile.Close();
                        return false;
                    }
                    for (int i = 0; i < TransactionLength - 1; i++)
                    {
                        Ifile.ReadLine();
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error " +(ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            Ifile.Close();
            return true;
        }
        /*
         Name: SearchFiltersButton_Click
         Description: Search the investment details by Email, date or Transaction ID.
         */
        private void SearchFiltersButton_Click(object sender, EventArgs e)
        {
            this.Text = "Search Details";
            SearchListBox.Items.Clear();
            
            if (!string.IsNullOrEmpty(SearchByDateTextBox.Text))
            {
                if (IDSearchRadioButton.Checked == true)
                {
                    SearchByID();
                }
                else if (SearchbyDateRadioButton.Checked == true)
                {
                    SearchByDate(SearchByDateTextBox.Text);
                }
                else if (SearchbyEmailRadioButton.Checked == true)
                {
                    SearchByEmail(SearchByDateTextBox.Text);
                }
                else
                {
                    MessageBox.Show("Please select the search option", "Selection required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please enter the search string", "Input required", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            for (int i = FORMSTARTHEIGHT; i < FORMEXPANDHEIGHT; i += INCREMENT)
            {
                this.Size = new Size(FORMWIDTH, i);
                this.Update();
                System.Threading.Thread.Sleep(1);
            }
        }
        /*
         Name: SearchByDate
         Description: Search the investment details by date.
         */
        private string SearchByDate(string SearchDates)
        {
            string pointer = null;
            Ifile = File.OpenText(FILENAME);
            string TempTransID;
            try
            {
                string SearchDate = SearchByDateTextBox.Text;
                while (!Ifile.EndOfStream)
                {
                    for (int i = 0; i < TransactionLength; i++)
                    {
                        TempTransID = Ifile.ReadLine();
                        pointer = Ifile.ReadLine();
                        if (pointer == SearchDate)
                        {
                            SearchListBox.Items.Add("TransactionID  : " + string.Format(TempTransID));
                            SearchListBox.Items.Add("Date :" + string.Format(pointer));
                            SearchListBox.Items.Add("Future Value :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Invested Amount :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("First Name :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Last Name :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Email ID :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Telephone No :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Term Selected :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Interest Accured :" + string.Format(Ifile.ReadLine()));
                        }
                    }
                }

                Ifile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally

            {
                if (Ifile != null)
                {
                    Ifile.Dispose(); // dispose the StreamReader if it's not null
                }
            }
            return SearchDates;
        }
        /*
         Name: SearchByEmail
         Description: Search the investment details by email.
         */
        private string SearchByEmail(string SearchEmail)
        {
            string pointer = null;
            Ifile = File.OpenText(FILENAME);
            string TempTransID, TempDate, TempFutureVal, TempInvestedAmount, TempFirstName5, TempLastName;
            try
            {
                string SearchEmailID = SearchByDateTextBox.Text;
                while (!Ifile.EndOfStream)
                {

                    for (int i = 0; i < TransactionLength; i++)
                    {
                        TempTransID = Ifile.ReadLine();
                        TempDate = Ifile.ReadLine();
                        TempFutureVal = Ifile.ReadLine();
                        TempInvestedAmount = Ifile.ReadLine();
                        TempFirstName5 = Ifile.ReadLine();
                        TempLastName = Ifile.ReadLine();
                        pointer = Ifile.ReadLine();
                        if (pointer == SearchEmailID)
                        {
                            SearchListBox.Items.Add("TransactionID  : " + string.Format(TempTransID));
                            SearchListBox.Items.Add("Date :" + string.Format(TempDate));
                            SearchListBox.Items.Add("Future Value :" + string.Format(TempFutureVal));
                            SearchListBox.Items.Add("Invested Amount :" + string.Format(TempInvestedAmount));
                            SearchListBox.Items.Add("First Name :" + string.Format(TempFirstName5));
                            SearchListBox.Items.Add("Last Name :" + string.Format(TempLastName));
                            SearchListBox.Items.Add("Email ID :" + string.Format(pointer));
                            SearchListBox.Items.Add("Telephone No :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Term Selected :" + string.Format(Ifile.ReadLine()));
                            SearchListBox.Items.Add("Interest Accured :" + string.Format(Ifile.ReadLine()));
                        }
                    }
                }
                Ifile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (Ifile != null)
                {
                    Ifile.Dispose(); // dispose the StreamReader if it's not null
                }
            }
            return SearchEmail;
        }
        /*
         Name: SearchByEmail
         Description: Search the investment details by Transaction ID.
         */
        private void SearchByID()
        {
            try
            {
                string pointer;
                Ifile = File.OpenText(FILENAME);
                while (!Ifile.EndOfStream)
                {
                    pointer = Ifile.ReadLine();
                    if (pointer == SearchByDateTextBox.Text)
                    {
                        SearchListBox.Items.Add("TransactionID  : " + string.Format(pointer));
                        SearchListBox.Items.Add("Date :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Future Value :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Invested Amount :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("First Name :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Last Name :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Email ID :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Telephone No :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Term Selected :" + string.Format(Ifile.ReadLine()));
                        SearchListBox.Items.Add("Interest Accured :" + string.Format(Ifile.ReadLine()));
                    }
                }
                Ifile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (Ifile != null)
                {
                    Ifile.Dispose(); // dispose the StreamReader if it's not null
                }
            }
        }
        /*
         Name: SummaryButton_Click
         Description: Displays the summary details. 
         */
        private void SummaryButton_Click(object sender, EventArgs e)
        {
            this.Text = "Summary Details";
            decimal AverageInvestedAmount;
            SummaryGroupBox.Visible = true;
            Proceed.Enabled = false;
            SubmitButton.Enabled = false;
            TransactionSummary();
            InvestmentsSummary();
            TermSummary();
            InterestSummary();
            AverageInvestedAmount = (TotalInvestmentAmount / TransCount);
            AverageInvestedAmountLabel.Text = AverageInvestedAmount.ToString("c");
            DisplayGroupBox.Visible = false;
            ProceedGroupBoxDetails.Visible = false;
            SearchGroupBox.Visible = false;
            //Form Expansion
            for (int i = FORMSTARTHEIGHT; i < FORMEXPANDHEIGHT; i += INCREMENT)
            {
                this.Size = new Size(FORMWIDTH, i);
                this.Update();
                System.Threading.Thread.Sleep(1);
            }
        }
        /*
         Name: TransactionSummary
         Description: Displays the summary details of the Transaction numbers and the count. 
         */
        private void TransactionSummary()
        {
            try
            {
                string pointer;
                TransCount = 0;
                Ifile = File.OpenText(FILENAME);
                while (!Ifile.EndOfStream)
                {
                    pointer = Ifile.ReadLine();
                    for (int i = 0; i < TransactionLength - 1; i++)
                    {
                        Ifile.ReadLine();
                    }
                    TransCount++;
                    SummaryListBox.Items.Add(pointer.ToString());
                }
                NoOfTrans.Text = TransCount.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Ifile.Close();
        }
        /*
         Name: InvestmentsSummary
         Description: Displays the summary details of the Total Investment amount. 
         */
        private void InvestmentsSummary()
        {
            try
            {
                string pointer;
                Ifile = File.OpenText(FILENAME);
                while (!Ifile.EndOfStream)
                {
                    for (int i = 0; i < TransactionLength - 7; i++)
                    {
                        Ifile.ReadLine();
                    }
                    pointer = Ifile.ReadLine();
                    for (int i = 0; i < TransactionLength - 4; i++)//skip the lines
                    {
                        Ifile.ReadLine();
                    }
                    TotalInvestmentAmount += decimal.Parse(pointer);
                }
                TotalInvAmountLabel.Text = TotalInvestmentAmount.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Ifile.Close();
        }
        /*
         Name: TermSummary
         Description: Displays the summary details of the Term Duration Average. 
         */
        private void TermSummary()
        {
            try
            {
                string pointer;
                Ifile = File.OpenText(FILENAME);
                while (!Ifile.EndOfStream)
                {
                    for (int i = 0; i < TransactionLength - 2; i++)
                    {
                        Ifile.ReadLine();
                    }
                    pointer = Ifile.ReadLine();
                    Ifile.ReadLine();
                    TotalTerm += int.Parse(pointer);
                }
                AverageTermValue.Text = (TotalTerm / TransCount).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Ifile.Close();
        }
        /*
         Name: InterestSummary
         Description: Displays the summary details of the Term Duration Average. 
         */
        private void InterestSummary()
        {
            try
            {
                string pointer;
                Ifile = File.OpenText(FILENAME);
                while (!Ifile.EndOfStream)
                {
                    for (int i = 0; i < TransactionLength - 1; i++)
                    {
                        Ifile.ReadLine();
                    }
                    pointer = Ifile.ReadLine();
                    TotalInterestAccrued += decimal.Parse(pointer);
                }
                IntLabel.Text = TotalInterestAccrued.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + (ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Ifile.Close();
        }
    }
}
