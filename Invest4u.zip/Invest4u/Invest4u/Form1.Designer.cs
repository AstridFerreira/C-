﻿namespace Invest4u
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Login = new System.Windows.Forms.Button();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.ButtonGroupBox = new System.Windows.Forms.GroupBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SummaryButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.Proceed = new System.Windows.Forms.Button();
            this.DisplayButton = new System.Windows.Forms.Button();
            this.ProceedGroupBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.InvestmentFutureValue = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.Trans = new System.Windows.Forms.Label();
            this.TelephoneNoTextBox = new System.Windows.Forms.TextBox();
            this.EmailIDTextBox = new System.Windows.Forms.TextBox();
            this.TelephoneNoLabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.LastNameTextbox = new System.Windows.Forms.TextBox();
            this.FirstNameTextbox = new System.Windows.Forms.TextBox();
            this.DateDisplayLabel = new System.Windows.Forms.Label();
            this.TransactionIDDisplay = new System.Windows.Forms.Label();
            this.InvestmentAmountLabel = new System.Windows.Forms.Label();
            this.InvestmentAmounttTextBox = new System.Windows.Forms.TextBox();
            this.DisplayGroupBox = new System.Windows.Forms.GroupBox();
            this.FutureValue = new System.Windows.Forms.Label();
            this.MoreThan = new System.Windows.Forms.Label();
            this.Upto = new System.Windows.Forms.Label();
            this.Term = new System.Windows.Forms.Label();
            this.TenYearLabel = new System.Windows.Forms.Label();
            this.FiveYearLabel = new System.Windows.Forms.Label();
            this.ThreeYearLabel = new System.Windows.Forms.Label();
            this.OneYearLabel = new System.Windows.Forms.Label();
            this.TenYearRadioButton = new System.Windows.Forms.RadioButton();
            this.FiveYearsRadioButton = new System.Windows.Forms.RadioButton();
            this.ThreeYearRadioButton = new System.Windows.Forms.RadioButton();
            this.OneYearRadioButton = new System.Windows.Forms.RadioButton();
            this.TermTenLabel = new System.Windows.Forms.Label();
            this.TermFiveLabel = new System.Windows.Forms.Label();
            this.TermThreeLabel = new System.Windows.Forms.Label();
            this.TermOneLabel = new System.Windows.Forms.Label();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.SearchbyEmailRadioButton = new System.Windows.Forms.RadioButton();
            this.SearchbyDateRadioButton = new System.Windows.Forms.RadioButton();
            this.IDSearchRadioButton = new System.Windows.Forms.RadioButton();
            this.SearchByDateTextBox = new System.Windows.Forms.TextBox();
            this.SearchFiltersButton = new System.Windows.Forms.Button();
            this.SearchListBox = new System.Windows.Forms.ListBox();
            this.EnterPassword = new System.Windows.Forms.Label();
            this.SummaryListBox = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.TransactionList = new System.Windows.Forms.Label();
            this.IntLabel = new System.Windows.Forms.Label();
            this.TotalInterestLabel = new System.Windows.Forms.Label();
            this.AverageTermValue = new System.Windows.Forms.Label();
            this.AverageTenure = new System.Windows.Forms.Label();
            this.AverageInvestedAmountLabel = new System.Windows.Forms.Label();
            this.AverageInvestedDisplayLabel = new System.Windows.Forms.Label();
            this.TotalInvAmountLabel = new System.Windows.Forms.Label();
            this.InvestedAmountLabel = new System.Windows.Forms.Label();
            this.NoOfTransDisplayLabel = new System.Windows.Forms.Label();
            this.NoOfTrans = new System.Windows.Forms.Label();
            this.ProceedGroupBoxDetails = new System.Windows.Forms.GroupBox();
            this.TeleTextbox = new System.Windows.Forms.TextBox();
            this.EmailTextbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EmailIDLabel = new System.Windows.Forms.Label();
            this.LastNTextbox = new System.Windows.Forms.TextBox();
            this.FirstNTextbox = new System.Windows.Forms.TextBox();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DisplayText = new System.Windows.Forms.Label();
            this.InvestmentFutureValueDisplayLabel = new System.Windows.Forms.Label();
            this.InvestmentFutureValueLabel = new System.Windows.Forms.Label();
            this.CurrentDateDisplayLabel = new System.Windows.Forms.Label();
            this.CurrentDateLabel = new System.Windows.Forms.Label();
            this.TransID = new System.Windows.Forms.Label();
            this.TransactionIDDisplayLabel = new System.Windows.Forms.Label();
            this.LoginGroupBox = new System.Windows.Forms.GroupBox();
            this.ExitToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ClearToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.LoginToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.SearchToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.SummaryToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.LoginTool = new System.Windows.Forms.ToolTip(this.components);
            this.SubmitToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ProceedToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.DisplayToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ButtonGroupBox.SuspendLayout();
            this.ProceedGroupBox.SuspendLayout();
            this.DisplayGroupBox.SuspendLayout();
            this.SearchGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SummaryGroupBox.SuspendLayout();
            this.ProceedGroupBoxDetails.SuspendLayout();
            this.LoginGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // Login
            // 
            this.Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Login.Location = new System.Drawing.Point(132, 60);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(81, 36);
            this.Login.TabIndex = 0;
            this.Login.Text = "Login";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(194, 28);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(100, 26);
            this.PasswordTextBox.TabIndex = 1;
            this.PasswordTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PasswordTextBox.TextChanged += new System.EventHandler(this.PasswordTextBox_TextChanged);
            // 
            // ButtonGroupBox
            // 
            this.ButtonGroupBox.Controls.Add(this.ExitButton);
            this.ButtonGroupBox.Controls.Add(this.ClearButton);
            this.ButtonGroupBox.Controls.Add(this.SearchButton);
            this.ButtonGroupBox.Controls.Add(this.SummaryButton);
            this.ButtonGroupBox.Controls.Add(this.SubmitButton);
            this.ButtonGroupBox.Controls.Add(this.Proceed);
            this.ButtonGroupBox.Controls.Add(this.DisplayButton);
            this.ButtonGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGroupBox.Location = new System.Drawing.Point(139, 269);
            this.ButtonGroupBox.Name = "ButtonGroupBox";
            this.ButtonGroupBox.Size = new System.Drawing.Size(877, 113);
            this.ButtonGroupBox.TabIndex = 2;
            this.ButtonGroupBox.TabStop = false;
            // 
            // ExitButton
            // 
            this.ExitButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.ExitButton.Location = new System.Drawing.Point(763, 53);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(79, 36);
            this.ExitButton.TabIndex = 18;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.ClearButton.Location = new System.Drawing.Point(656, 53);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 36);
            this.ClearButton.TabIndex = 17;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SearchButton.Location = new System.Drawing.Point(524, 53);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(98, 35);
            this.SearchButton.TabIndex = 10;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SummaryButton
            // 
            this.SummaryButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SummaryButton.Location = new System.Drawing.Point(389, 54);
            this.SummaryButton.Name = "SummaryButton";
            this.SummaryButton.Size = new System.Drawing.Size(104, 32);
            this.SummaryButton.TabIndex = 9;
            this.SummaryButton.Text = "Summary";
            this.SummaryButton.UseVisualStyleBackColor = true;
            this.SummaryButton.Click += new System.EventHandler(this.SummaryButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SubmitButton.Location = new System.Drawing.Point(263, 53);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(106, 33);
            this.SubmitButton.TabIndex = 8;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // Proceed
            // 
            this.Proceed.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Proceed.Location = new System.Drawing.Point(137, 52);
            this.Proceed.Name = "Proceed";
            this.Proceed.Size = new System.Drawing.Size(101, 35);
            this.Proceed.TabIndex = 6;
            this.Proceed.Text = "Proceed";
            this.Proceed.UseVisualStyleBackColor = true;
            this.Proceed.Click += new System.EventHandler(this.Proceed_Click);
            // 
            // DisplayButton
            // 
            this.DisplayButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.DisplayButton.Location = new System.Drawing.Point(30, 52);
            this.DisplayButton.Name = "DisplayButton";
            this.DisplayButton.Size = new System.Drawing.Size(87, 35);
            this.DisplayButton.TabIndex = 0;
            this.DisplayButton.Text = "Display";
            this.DisplayButton.UseVisualStyleBackColor = true;
            this.DisplayButton.Click += new System.EventHandler(this.DisplayButton_Click);
            // 
            // ProceedGroupBox
            // 
            this.ProceedGroupBox.Controls.Add(this.label1);
            this.ProceedGroupBox.Controls.Add(this.InvestmentFutureValue);
            this.ProceedGroupBox.Controls.Add(this.Date);
            this.ProceedGroupBox.Controls.Add(this.Trans);
            this.ProceedGroupBox.Controls.Add(this.TelephoneNoTextBox);
            this.ProceedGroupBox.Controls.Add(this.EmailIDTextBox);
            this.ProceedGroupBox.Controls.Add(this.TelephoneNoLabel);
            this.ProceedGroupBox.Controls.Add(this.EmailLabel);
            this.ProceedGroupBox.Controls.Add(this.LastNameLabel);
            this.ProceedGroupBox.Controls.Add(this.FirstNameLabel);
            this.ProceedGroupBox.Controls.Add(this.LastNameTextbox);
            this.ProceedGroupBox.Controls.Add(this.FirstNameTextbox);
            this.ProceedGroupBox.Controls.Add(this.DateDisplayLabel);
            this.ProceedGroupBox.Controls.Add(this.TransactionIDDisplay);
            this.ProceedGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProceedGroupBox.Location = new System.Drawing.Point(27, 176);
            this.ProceedGroupBox.Name = "ProceedGroupBox";
            this.ProceedGroupBox.Size = new System.Drawing.Size(634, 155);
            this.ProceedGroupBox.TabIndex = 7;
            this.ProceedGroupBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Future Value:";
            // 
            // InvestmentFutureValue
            // 
            this.InvestmentFutureValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InvestmentFutureValue.Location = new System.Drawing.Point(166, 11);
            this.InvestmentFutureValue.Name = "InvestmentFutureValue";
            this.InvestmentFutureValue.Size = new System.Drawing.Size(156, 20);
            this.InvestmentFutureValue.TabIndex = 12;
            this.InvestmentFutureValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(370, 42);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(53, 20);
            this.Date.TabIndex = 11;
            this.Date.Text = "Date:";
            // 
            // Trans
            // 
            this.Trans.AutoSize = true;
            this.Trans.Location = new System.Drawing.Point(13, 42);
            this.Trans.Name = "Trans";
            this.Trans.Size = new System.Drawing.Size(132, 20);
            this.Trans.TabIndex = 10;
            this.Trans.Text = "Transaction ID:";
            // 
            // TelephoneNoTextBox
            // 
            this.TelephoneNoTextBox.Location = new System.Drawing.Point(493, 107);
            this.TelephoneNoTextBox.Name = "TelephoneNoTextBox";
            this.TelephoneNoTextBox.Size = new System.Drawing.Size(100, 26);
            this.TelephoneNoTextBox.TabIndex = 9;
            // 
            // EmailIDTextBox
            // 
            this.EmailIDTextBox.Location = new System.Drawing.Point(120, 104);
            this.EmailIDTextBox.Name = "EmailIDTextBox";
            this.EmailIDTextBox.Size = new System.Drawing.Size(100, 26);
            this.EmailIDTextBox.TabIndex = 8;
            // 
            // TelephoneNoLabel
            // 
            this.TelephoneNoLabel.AutoSize = true;
            this.TelephoneNoLabel.Location = new System.Drawing.Point(370, 107);
            this.TelephoneNoLabel.Name = "TelephoneNoLabel";
            this.TelephoneNoLabel.Size = new System.Drawing.Size(120, 20);
            this.TelephoneNoLabel.TabIndex = 7;
            this.TelephoneNoLabel.Text = "TelephoneNo:";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(13, 110);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(82, 20);
            this.EmailLabel.TabIndex = 6;
            this.EmailLabel.Text = "Email ID:";
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(370, 78);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(100, 20);
            this.LastNameLabel.TabIndex = 5;
            this.LastNameLabel.Text = "Last Name:";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(13, 72);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(101, 20);
            this.FirstNameLabel.TabIndex = 4;
            this.FirstNameLabel.Text = "First Name:";
            // 
            // LastNameTextbox
            // 
            this.LastNameTextbox.Location = new System.Drawing.Point(493, 72);
            this.LastNameTextbox.Name = "LastNameTextbox";
            this.LastNameTextbox.Size = new System.Drawing.Size(100, 26);
            this.LastNameTextbox.TabIndex = 3;
            // 
            // FirstNameTextbox
            // 
            this.FirstNameTextbox.Location = new System.Drawing.Point(120, 72);
            this.FirstNameTextbox.Name = "FirstNameTextbox";
            this.FirstNameTextbox.Size = new System.Drawing.Size(100, 26);
            this.FirstNameTextbox.TabIndex = 2;
            // 
            // DateDisplayLabel
            // 
            this.DateDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DateDisplayLabel.Location = new System.Drawing.Point(493, 42);
            this.DateDisplayLabel.Name = "DateDisplayLabel";
            this.DateDisplayLabel.Size = new System.Drawing.Size(115, 20);
            this.DateDisplayLabel.TabIndex = 1;
            this.DateDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TransactionIDDisplay
            // 
            this.TransactionIDDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TransactionIDDisplay.Location = new System.Drawing.Point(166, 42);
            this.TransactionIDDisplay.Name = "TransactionIDDisplay";
            this.TransactionIDDisplay.Size = new System.Drawing.Size(156, 20);
            this.TransactionIDDisplay.TabIndex = 0;
            this.TransactionIDDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // InvestmentAmountLabel
            // 
            this.InvestmentAmountLabel.AutoSize = true;
            this.InvestmentAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestmentAmountLabel.Location = new System.Drawing.Point(306, 237);
            this.InvestmentAmountLabel.Name = "InvestmentAmountLabel";
            this.InvestmentAmountLabel.Size = new System.Drawing.Size(291, 20);
            this.InvestmentAmountLabel.TabIndex = 3;
            this.InvestmentAmountLabel.Text = "How much would you like to invest?";
            // 
            // InvestmentAmounttTextBox
            // 
            this.InvestmentAmounttTextBox.Location = new System.Drawing.Point(622, 237);
            this.InvestmentAmounttTextBox.Name = "InvestmentAmounttTextBox";
            this.InvestmentAmounttTextBox.Size = new System.Drawing.Size(116, 26);
            this.InvestmentAmounttTextBox.TabIndex = 4;
            this.InvestmentAmounttTextBox.TextChanged += new System.EventHandler(this.InvestmentAmounttTextBox_TextChanged);
            // 
            // DisplayGroupBox
            // 
            this.DisplayGroupBox.Controls.Add(this.FutureValue);
            this.DisplayGroupBox.Controls.Add(this.MoreThan);
            this.DisplayGroupBox.Controls.Add(this.Upto);
            this.DisplayGroupBox.Controls.Add(this.Term);
            this.DisplayGroupBox.Controls.Add(this.TenYearLabel);
            this.DisplayGroupBox.Controls.Add(this.FiveYearLabel);
            this.DisplayGroupBox.Controls.Add(this.ThreeYearLabel);
            this.DisplayGroupBox.Controls.Add(this.ProceedGroupBox);
            this.DisplayGroupBox.Controls.Add(this.OneYearLabel);
            this.DisplayGroupBox.Controls.Add(this.TenYearRadioButton);
            this.DisplayGroupBox.Controls.Add(this.FiveYearsRadioButton);
            this.DisplayGroupBox.Controls.Add(this.ThreeYearRadioButton);
            this.DisplayGroupBox.Controls.Add(this.OneYearRadioButton);
            this.DisplayGroupBox.Controls.Add(this.TermTenLabel);
            this.DisplayGroupBox.Controls.Add(this.TermFiveLabel);
            this.DisplayGroupBox.Controls.Add(this.TermThreeLabel);
            this.DisplayGroupBox.Controls.Add(this.TermOneLabel);
            this.DisplayGroupBox.Location = new System.Drawing.Point(95, 427);
            this.DisplayGroupBox.Name = "DisplayGroupBox";
            this.DisplayGroupBox.Size = new System.Drawing.Size(699, 187);
            this.DisplayGroupBox.TabIndex = 5;
            this.DisplayGroupBox.TabStop = false;
            // 
            // FutureValue
            // 
            this.FutureValue.AutoSize = true;
            this.FutureValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FutureValue.Location = new System.Drawing.Point(494, 22);
            this.FutureValue.Name = "FutureValue";
            this.FutureValue.Size = new System.Drawing.Size(113, 20);
            this.FutureValue.TabIndex = 21;
            this.FutureValue.Text = "Future Value";
            // 
            // MoreThan
            // 
            this.MoreThan.AutoSize = true;
            this.MoreThan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoreThan.Location = new System.Drawing.Point(295, 22);
            this.MoreThan.Name = "MoreThan";
            this.MoreThan.Size = new System.Drawing.Size(155, 20);
            this.MoreThan.TabIndex = 20;
            this.MoreThan.Text = "More than 100000";
            // 
            // Upto
            // 
            this.Upto.AutoSize = true;
            this.Upto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Upto.Location = new System.Drawing.Point(151, 22);
            this.Upto.Name = "Upto";
            this.Upto.Size = new System.Drawing.Size(113, 20);
            this.Upto.TabIndex = 19;
            this.Upto.Text = "Upto 100000";
            // 
            // Term
            // 
            this.Term.AutoSize = true;
            this.Term.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Term.Location = new System.Drawing.Point(32, 22);
            this.Term.Name = "Term";
            this.Term.Size = new System.Drawing.Size(49, 20);
            this.Term.TabIndex = 18;
            this.Term.Text = "Term";
            // 
            // TenYearLabel
            // 
            this.TenYearLabel.AutoSize = true;
            this.TenYearLabel.Location = new System.Drawing.Point(169, 146);
            this.TenYearLabel.Name = "TenYearLabel";
            this.TenYearLabel.Size = new System.Drawing.Size(231, 20);
            this.TenYearLabel.TabIndex = 17;
            this.TenYearLabel.Text = "0.011250%               0.012500%";
            // 
            // FiveYearLabel
            // 
            this.FiveYearLabel.AutoSize = true;
            this.FiveYearLabel.Location = new System.Drawing.Point(169, 116);
            this.FiveYearLabel.Name = "FiveYearLabel";
            this.FiveYearLabel.Size = new System.Drawing.Size(231, 20);
            this.FiveYearLabel.TabIndex = 16;
            this.FiveYearLabel.Text = "0.007125%               0.008125%";
            // 
            // ThreeYearLabel
            // 
            this.ThreeYearLabel.AutoSize = true;
            this.ThreeYearLabel.Location = new System.Drawing.Point(169, 85);
            this.ThreeYearLabel.Name = "ThreeYearLabel";
            this.ThreeYearLabel.Size = new System.Drawing.Size(231, 20);
            this.ThreeYearLabel.TabIndex = 15;
            this.ThreeYearLabel.Text = "0.006250%               0.007250%";
            // 
            // OneYearLabel
            // 
            this.OneYearLabel.AutoSize = true;
            this.OneYearLabel.Location = new System.Drawing.Point(169, 57);
            this.OneYearLabel.Name = "OneYearLabel";
            this.OneYearLabel.Size = new System.Drawing.Size(231, 20);
            this.OneYearLabel.TabIndex = 14;
            this.OneYearLabel.Text = "0.005000%               0.006000%";
            // 
            // TenYearRadioButton
            // 
            this.TenYearRadioButton.AutoSize = true;
            this.TenYearRadioButton.Location = new System.Drawing.Point(6, 146);
            this.TenYearRadioButton.Name = "TenYearRadioButton";
            this.TenYearRadioButton.Size = new System.Drawing.Size(94, 24);
            this.TenYearRadioButton.TabIndex = 13;
            this.TenYearRadioButton.TabStop = true;
            this.TenYearRadioButton.Text = "10 years";
            this.TenYearRadioButton.UseVisualStyleBackColor = true;
            this.TenYearRadioButton.CheckedChanged += new System.EventHandler(this.TenYearRadioButton_CheckedChanged);
            // 
            // FiveYearsRadioButton
            // 
            this.FiveYearsRadioButton.AutoSize = true;
            this.FiveYearsRadioButton.Location = new System.Drawing.Point(6, 116);
            this.FiveYearsRadioButton.Name = "FiveYearsRadioButton";
            this.FiveYearsRadioButton.Size = new System.Drawing.Size(85, 24);
            this.FiveYearsRadioButton.TabIndex = 12;
            this.FiveYearsRadioButton.TabStop = true;
            this.FiveYearsRadioButton.Text = "5 years";
            this.FiveYearsRadioButton.UseVisualStyleBackColor = true;
            this.FiveYearsRadioButton.CheckedChanged += new System.EventHandler(this.FiveYearsRadioButton_CheckedChanged);
            // 
            // ThreeYearRadioButton
            // 
            this.ThreeYearRadioButton.AutoSize = true;
            this.ThreeYearRadioButton.Location = new System.Drawing.Point(6, 85);
            this.ThreeYearRadioButton.Name = "ThreeYearRadioButton";
            this.ThreeYearRadioButton.Size = new System.Drawing.Size(85, 24);
            this.ThreeYearRadioButton.TabIndex = 11;
            this.ThreeYearRadioButton.TabStop = true;
            this.ThreeYearRadioButton.Text = "3 years";
            this.ThreeYearRadioButton.UseVisualStyleBackColor = true;
            this.ThreeYearRadioButton.CheckedChanged += new System.EventHandler(this.ThreeYearRadioButton_CheckedChanged);
            // 
            // OneYearRadioButton
            // 
            this.OneYearRadioButton.AutoSize = true;
            this.OneYearRadioButton.Location = new System.Drawing.Point(6, 54);
            this.OneYearRadioButton.Name = "OneYearRadioButton";
            this.OneYearRadioButton.Size = new System.Drawing.Size(77, 24);
            this.OneYearRadioButton.TabIndex = 10;
            this.OneYearRadioButton.TabStop = true;
            this.OneYearRadioButton.Text = "1 year";
            this.OneYearRadioButton.UseVisualStyleBackColor = true;
            this.OneYearRadioButton.CheckedChanged += new System.EventHandler(this.OneYearRadioButton_CheckedChanged);
            // 
            // TermTenLabel
            // 
            this.TermTenLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TermTenLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermTenLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TermTenLabel.Location = new System.Drawing.Point(480, 146);
            this.TermTenLabel.Name = "TermTenLabel";
            this.TermTenLabel.Size = new System.Drawing.Size(159, 24);
            this.TermTenLabel.TabIndex = 9;
            this.TermTenLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TermFiveLabel
            // 
            this.TermFiveLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TermFiveLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermFiveLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TermFiveLabel.Location = new System.Drawing.Point(480, 116);
            this.TermFiveLabel.Name = "TermFiveLabel";
            this.TermFiveLabel.Size = new System.Drawing.Size(159, 24);
            this.TermFiveLabel.TabIndex = 8;
            this.TermFiveLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TermThreeLabel
            // 
            this.TermThreeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TermThreeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermThreeLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TermThreeLabel.Location = new System.Drawing.Point(479, 85);
            this.TermThreeLabel.Name = "TermThreeLabel";
            this.TermThreeLabel.Size = new System.Drawing.Size(160, 24);
            this.TermThreeLabel.TabIndex = 7;
            this.TermThreeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TermOneLabel
            // 
            this.TermOneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TermOneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermOneLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TermOneLabel.Location = new System.Drawing.Point(479, 54);
            this.TermOneLabel.Name = "TermOneLabel";
            this.TermOneLabel.Size = new System.Drawing.Size(160, 24);
            this.TermOneLabel.TabIndex = 6;
            this.TermOneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.Controls.Add(this.SearchbyEmailRadioButton);
            this.SearchGroupBox.Controls.Add(this.SearchbyDateRadioButton);
            this.SearchGroupBox.Controls.Add(this.IDSearchRadioButton);
            this.SearchGroupBox.Controls.Add(this.SearchByDateTextBox);
            this.SearchGroupBox.Controls.Add(this.SearchFiltersButton);
            this.SearchGroupBox.Controls.Add(this.SearchListBox);
            this.SearchGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchGroupBox.Location = new System.Drawing.Point(454, 401);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(358, 459);
            this.SearchGroupBox.TabIndex = 11;
            this.SearchGroupBox.TabStop = false;
            // 
            // SearchbyEmailRadioButton
            // 
            this.SearchbyEmailRadioButton.AutoSize = true;
            this.SearchbyEmailRadioButton.Location = new System.Drawing.Point(24, 105);
            this.SearchbyEmailRadioButton.Name = "SearchbyEmailRadioButton";
            this.SearchbyEmailRadioButton.Size = new System.Drawing.Size(187, 24);
            this.SearchbyEmailRadioButton.TabIndex = 10;
            this.SearchbyEmailRadioButton.TabStop = true;
            this.SearchbyEmailRadioButton.Text = "Search by Email ID";
            this.SearchbyEmailRadioButton.UseVisualStyleBackColor = true;
            // 
            // SearchbyDateRadioButton
            // 
            this.SearchbyDateRadioButton.AutoSize = true;
            this.SearchbyDateRadioButton.Location = new System.Drawing.Point(24, 75);
            this.SearchbyDateRadioButton.Name = "SearchbyDateRadioButton";
            this.SearchbyDateRadioButton.Size = new System.Drawing.Size(282, 24);
            this.SearchbyDateRadioButton.TabIndex = 9;
            this.SearchbyDateRadioButton.TabStop = true;
            this.SearchbyDateRadioButton.Text = "Search by Date(DD/MM/YYYY)";
            this.SearchbyDateRadioButton.UseVisualStyleBackColor = true;
            // 
            // IDSearchRadioButton
            // 
            this.IDSearchRadioButton.AutoSize = true;
            this.IDSearchRadioButton.Location = new System.Drawing.Point(24, 45);
            this.IDSearchRadioButton.Name = "IDSearchRadioButton";
            this.IDSearchRadioButton.Size = new System.Drawing.Size(138, 24);
            this.IDSearchRadioButton.TabIndex = 8;
            this.IDSearchRadioButton.TabStop = true;
            this.IDSearchRadioButton.Text = "Search by ID";
            this.IDSearchRadioButton.UseVisualStyleBackColor = true;
            // 
            // SearchByDateTextBox
            // 
            this.SearchByDateTextBox.Location = new System.Drawing.Point(85, 153);
            this.SearchByDateTextBox.Name = "SearchByDateTextBox";
            this.SearchByDateTextBox.Size = new System.Drawing.Size(169, 26);
            this.SearchByDateTextBox.TabIndex = 5;
            // 
            // SearchFiltersButton
            // 
            this.SearchFiltersButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SearchFiltersButton.Location = new System.Drawing.Point(100, 189);
            this.SearchFiltersButton.Name = "SearchFiltersButton";
            this.SearchFiltersButton.Size = new System.Drawing.Size(134, 37);
            this.SearchFiltersButton.TabIndex = 3;
            this.SearchFiltersButton.Text = "Search Now";
            this.SearchFiltersButton.UseVisualStyleBackColor = true;
            this.SearchFiltersButton.Click += new System.EventHandler(this.SearchFiltersButton_Click);
            // 
            // SearchListBox
            // 
            this.SearchListBox.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SearchListBox.FormattingEnabled = true;
            this.SearchListBox.ItemHeight = 20;
            this.SearchListBox.Location = new System.Drawing.Point(26, 232);
            this.SearchListBox.Name = "SearchListBox";
            this.SearchListBox.Size = new System.Drawing.Size(309, 204);
            this.SearchListBox.TabIndex = 2;
            // 
            // EnterPassword
            // 
            this.EnterPassword.AutoSize = true;
            this.EnterPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.EnterPassword.Location = new System.Drawing.Point(29, 31);
            this.EnterPassword.Name = "EnterPassword";
            this.EnterPassword.Size = new System.Drawing.Size(140, 20);
            this.EnterPassword.TabIndex = 12;
            this.EnterPassword.Text = "Enter Password:";
            // 
            // SummaryListBox
            // 
            this.SummaryListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryListBox.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SummaryListBox.FormattingEnabled = true;
            this.SummaryListBox.ItemHeight = 20;
            this.SummaryListBox.Location = new System.Drawing.Point(26, 232);
            this.SummaryListBox.Name = "SummaryListBox";
            this.SummaryListBox.Size = new System.Drawing.Size(303, 224);
            this.SummaryListBox.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Invest4u.Properties.Resources.Invest4U_Logo1;
            this.pictureBox1.Location = new System.Drawing.Point(526, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(158, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // SummaryGroupBox
            // 
            this.SummaryGroupBox.Controls.Add(this.TransactionList);
            this.SummaryGroupBox.Controls.Add(this.IntLabel);
            this.SummaryGroupBox.Controls.Add(this.TotalInterestLabel);
            this.SummaryGroupBox.Controls.Add(this.AverageTermValue);
            this.SummaryGroupBox.Controls.Add(this.AverageTenure);
            this.SummaryGroupBox.Controls.Add(this.AverageInvestedAmountLabel);
            this.SummaryGroupBox.Controls.Add(this.AverageInvestedDisplayLabel);
            this.SummaryGroupBox.Controls.Add(this.TotalInvAmountLabel);
            this.SummaryGroupBox.Controls.Add(this.InvestedAmountLabel);
            this.SummaryGroupBox.Controls.Add(this.NoOfTransDisplayLabel);
            this.SummaryGroupBox.Controls.Add(this.NoOfTrans);
            this.SummaryGroupBox.Controls.Add(this.SummaryListBox);
            this.SummaryGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryGroupBox.Location = new System.Drawing.Point(379, 404);
            this.SummaryGroupBox.Name = "SummaryGroupBox";
            this.SummaryGroupBox.Size = new System.Drawing.Size(439, 480);
            this.SummaryGroupBox.TabIndex = 15;
            this.SummaryGroupBox.TabStop = false;
            // 
            // TransactionList
            // 
            this.TransactionList.AutoSize = true;
            this.TransactionList.Location = new System.Drawing.Point(48, 210);
            this.TransactionList.Name = "TransactionList";
            this.TransactionList.Size = new System.Drawing.Size(216, 20);
            this.TransactionList.TabIndex = 24;
            this.TransactionList.Text = "List of All Transaction IDs";
            // 
            // IntLabel
            // 
            this.IntLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IntLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IntLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.IntLabel.Location = new System.Drawing.Point(188, 169);
            this.IntLabel.Name = "IntLabel";
            this.IntLabel.Size = new System.Drawing.Size(189, 24);
            this.IntLabel.TabIndex = 23;
            this.IntLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalInterestLabel
            // 
            this.TotalInterestLabel.AutoSize = true;
            this.TotalInterestLabel.Location = new System.Drawing.Point(12, 167);
            this.TotalInterestLabel.Name = "TotalInterestLabel";
            this.TotalInterestLabel.Size = new System.Drawing.Size(117, 20);
            this.TotalInterestLabel.TabIndex = 22;
            this.TotalInterestLabel.Text = "Total Interest";
            // 
            // AverageTermValue
            // 
            this.AverageTermValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AverageTermValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageTermValue.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AverageTermValue.Location = new System.Drawing.Point(188, 131);
            this.AverageTermValue.Name = "AverageTermValue";
            this.AverageTermValue.Size = new System.Drawing.Size(189, 24);
            this.AverageTermValue.TabIndex = 21;
            this.AverageTermValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AverageTenure
            // 
            this.AverageTenure.AutoSize = true;
            this.AverageTenure.Location = new System.Drawing.Point(11, 135);
            this.AverageTenure.Name = "AverageTenure";
            this.AverageTenure.Size = new System.Drawing.Size(136, 20);
            this.AverageTenure.TabIndex = 20;
            this.AverageTenure.Text = "Average Tenure";
            // 
            // AverageInvestedAmountLabel
            // 
            this.AverageInvestedAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AverageInvestedAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageInvestedAmountLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AverageInvestedAmountLabel.Location = new System.Drawing.Point(188, 101);
            this.AverageInvestedAmountLabel.Name = "AverageInvestedAmountLabel";
            this.AverageInvestedAmountLabel.Size = new System.Drawing.Size(189, 22);
            this.AverageInvestedAmountLabel.TabIndex = 19;
            this.AverageInvestedAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AverageInvestedDisplayLabel
            // 
            this.AverageInvestedDisplayLabel.AutoSize = true;
            this.AverageInvestedDisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.AverageInvestedDisplayLabel.Name = "AverageInvestedDisplayLabel";
            this.AverageInvestedDisplayLabel.Size = new System.Drawing.Size(178, 20);
            this.AverageInvestedDisplayLabel.TabIndex = 18;
            this.AverageInvestedDisplayLabel.Text = "Average Investments";
            // 
            // TotalInvAmountLabel
            // 
            this.TotalInvAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalInvAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalInvAmountLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TotalInvAmountLabel.Location = new System.Drawing.Point(188, 61);
            this.TotalInvAmountLabel.Name = "TotalInvAmountLabel";
            this.TotalInvAmountLabel.Size = new System.Drawing.Size(189, 25);
            this.TotalInvAmountLabel.TabIndex = 17;
            this.TotalInvAmountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // InvestedAmountLabel
            // 
            this.InvestedAmountLabel.AutoSize = true;
            this.InvestedAmountLabel.Location = new System.Drawing.Point(11, 66);
            this.InvestedAmountLabel.Name = "InvestedAmountLabel";
            this.InvestedAmountLabel.Size = new System.Drawing.Size(140, 20);
            this.InvestedAmountLabel.TabIndex = 16;
            this.InvestedAmountLabel.Text = "InvestedAmount";
            // 
            // NoOfTransDisplayLabel
            // 
            this.NoOfTransDisplayLabel.AutoSize = true;
            this.NoOfTransDisplayLabel.Location = new System.Drawing.Point(11, 26);
            this.NoOfTransDisplayLabel.Name = "NoOfTransDisplayLabel";
            this.NoOfTransDisplayLabel.Size = new System.Drawing.Size(163, 20);
            this.NoOfTransDisplayLabel.TabIndex = 15;
            this.NoOfTransDisplayLabel.Text = "No Of Transactions";
            // 
            // NoOfTrans
            // 
            this.NoOfTrans.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NoOfTrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NoOfTrans.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.NoOfTrans.Location = new System.Drawing.Point(188, 26);
            this.NoOfTrans.Name = "NoOfTrans";
            this.NoOfTrans.Size = new System.Drawing.Size(189, 24);
            this.NoOfTrans.TabIndex = 14;
            this.NoOfTrans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProceedGroupBoxDetails
            // 
            this.ProceedGroupBoxDetails.Controls.Add(this.TeleTextbox);
            this.ProceedGroupBoxDetails.Controls.Add(this.EmailTextbox);
            this.ProceedGroupBoxDetails.Controls.Add(this.label3);
            this.ProceedGroupBoxDetails.Controls.Add(this.EmailIDLabel);
            this.ProceedGroupBoxDetails.Controls.Add(this.LastNTextbox);
            this.ProceedGroupBoxDetails.Controls.Add(this.FirstNTextbox);
            this.ProceedGroupBoxDetails.Controls.Add(this.SurnameLabel);
            this.ProceedGroupBoxDetails.Controls.Add(this.label2);
            this.ProceedGroupBoxDetails.Controls.Add(this.DisplayText);
            this.ProceedGroupBoxDetails.Controls.Add(this.InvestmentFutureValueDisplayLabel);
            this.ProceedGroupBoxDetails.Controls.Add(this.InvestmentFutureValueLabel);
            this.ProceedGroupBoxDetails.Controls.Add(this.CurrentDateDisplayLabel);
            this.ProceedGroupBoxDetails.Controls.Add(this.CurrentDateLabel);
            this.ProceedGroupBoxDetails.Controls.Add(this.TransID);
            this.ProceedGroupBoxDetails.Controls.Add(this.TransactionIDDisplayLabel);
            this.ProceedGroupBoxDetails.Location = new System.Drawing.Point(211, 413);
            this.ProceedGroupBoxDetails.Name = "ProceedGroupBoxDetails";
            this.ProceedGroupBoxDetails.Size = new System.Drawing.Size(699, 213);
            this.ProceedGroupBoxDetails.TabIndex = 16;
            this.ProceedGroupBoxDetails.TabStop = false;
            // 
            // TeleTextbox
            // 
            this.TeleTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleTextbox.Location = new System.Drawing.Point(507, 163);
            this.TeleTextbox.Name = "TeleTextbox";
            this.TeleTextbox.Size = new System.Drawing.Size(100, 26);
            this.TeleTextbox.TabIndex = 14;
            this.TeleTextbox.TextChanged += new System.EventHandler(this.TeleTextbox_TextChanged);
            // 
            // EmailTextbox
            // 
            this.EmailTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailTextbox.Location = new System.Drawing.Point(155, 163);
            this.EmailTextbox.Name = "EmailTextbox";
            this.EmailTextbox.Size = new System.Drawing.Size(100, 26);
            this.EmailTextbox.TabIndex = 13;
            this.EmailTextbox.TextChanged += new System.EventHandler(this.EmailTextbox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(393, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Telephone #";
            // 
            // EmailIDLabel
            // 
            this.EmailIDLabel.AutoSize = true;
            this.EmailIDLabel.Location = new System.Drawing.Point(27, 169);
            this.EmailIDLabel.Name = "EmailIDLabel";
            this.EmailIDLabel.Size = new System.Drawing.Size(69, 20);
            this.EmailIDLabel.TabIndex = 11;
            this.EmailIDLabel.Text = "Email ID";
            // 
            // LastNTextbox
            // 
            this.LastNTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastNTextbox.Location = new System.Drawing.Point(507, 126);
            this.LastNTextbox.Name = "LastNTextbox";
            this.LastNTextbox.Size = new System.Drawing.Size(100, 26);
            this.LastNTextbox.TabIndex = 10;
            this.LastNTextbox.TextChanged += new System.EventHandler(this.LastNTextbox_TextChanged);
            // 
            // FirstNTextbox
            // 
            this.FirstNTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNTextbox.Location = new System.Drawing.Point(155, 129);
            this.FirstNTextbox.Name = "FirstNTextbox";
            this.FirstNTextbox.Size = new System.Drawing.Size(100, 26);
            this.FirstNTextbox.TabIndex = 9;
            this.FirstNTextbox.TextChanged += new System.EventHandler(this.FirstNTextbox_TextChanged);
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Location = new System.Drawing.Point(393, 129);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(86, 20);
            this.SurnameLabel.TabIndex = 8;
            this.SurnameLabel.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "First Name";
            // 
            // DisplayText
            // 
            this.DisplayText.AutoSize = true;
            this.DisplayText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayText.Location = new System.Drawing.Point(27, 101);
            this.DisplayText.Name = "DisplayText";
            this.DisplayText.Size = new System.Drawing.Size(257, 20);
            this.DisplayText.TabIndex = 6;
            this.DisplayText.Text = "Please Enter the details below:";
            // 
            // InvestmentFutureValueDisplayLabel
            // 
            this.InvestmentFutureValueDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InvestmentFutureValueDisplayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestmentFutureValueDisplayLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.InvestmentFutureValueDisplayLabel.Location = new System.Drawing.Point(234, 53);
            this.InvestmentFutureValueDisplayLabel.Name = "InvestmentFutureValueDisplayLabel";
            this.InvestmentFutureValueDisplayLabel.Size = new System.Drawing.Size(126, 29);
            this.InvestmentFutureValueDisplayLabel.TabIndex = 5;
            this.InvestmentFutureValueDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // InvestmentFutureValueLabel
            // 
            this.InvestmentFutureValueLabel.AutoSize = true;
            this.InvestmentFutureValueLabel.Location = new System.Drawing.Point(27, 62);
            this.InvestmentFutureValueLabel.Name = "InvestmentFutureValueLabel";
            this.InvestmentFutureValueLabel.Size = new System.Drawing.Size(184, 20);
            this.InvestmentFutureValueLabel.TabIndex = 4;
            this.InvestmentFutureValueLabel.Text = "Investment Future Value";
            // 
            // CurrentDateDisplayLabel
            // 
            this.CurrentDateDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CurrentDateDisplayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentDateDisplayLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.CurrentDateDisplayLabel.Location = new System.Drawing.Point(507, 22);
            this.CurrentDateDisplayLabel.Name = "CurrentDateDisplayLabel";
            this.CurrentDateDisplayLabel.Size = new System.Drawing.Size(141, 29);
            this.CurrentDateDisplayLabel.TabIndex = 3;
            this.CurrentDateDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CurrentDateLabel
            // 
            this.CurrentDateLabel.AutoSize = true;
            this.CurrentDateLabel.Location = new System.Drawing.Point(402, 24);
            this.CurrentDateLabel.Name = "CurrentDateLabel";
            this.CurrentDateLabel.Size = new System.Drawing.Size(48, 20);
            this.CurrentDateLabel.TabIndex = 2;
            this.CurrentDateLabel.Text = "Date ";
            // 
            // TransID
            // 
            this.TransID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TransID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransID.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TransID.Location = new System.Drawing.Point(234, 21);
            this.TransID.Name = "TransID";
            this.TransID.Size = new System.Drawing.Size(126, 23);
            this.TransID.TabIndex = 1;
            this.TransID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TransactionIDDisplayLabel
            // 
            this.TransactionIDDisplayLabel.AutoSize = true;
            this.TransactionIDDisplayLabel.Location = new System.Drawing.Point(28, 21);
            this.TransactionIDDisplayLabel.Name = "TransactionIDDisplayLabel";
            this.TransactionIDDisplayLabel.Size = new System.Drawing.Size(113, 20);
            this.TransactionIDDisplayLabel.TabIndex = 0;
            this.TransactionIDDisplayLabel.Text = "Transaction ID";
            // 
            // LoginGroupBox
            // 
            this.LoginGroupBox.Controls.Add(this.EnterPassword);
            this.LoginGroupBox.Controls.Add(this.PasswordTextBox);
            this.LoginGroupBox.Controls.Add(this.Login);
            this.LoginGroupBox.Location = new System.Drawing.Point(428, 118);
            this.LoginGroupBox.Name = "LoginGroupBox";
            this.LoginGroupBox.Size = new System.Drawing.Size(351, 113);
            this.LoginGroupBox.TabIndex = 19;
            this.LoginGroupBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1186, 896);
            this.Controls.Add(this.LoginGroupBox);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.SummaryGroupBox);
            this.Controls.Add(this.ProceedGroupBoxDetails);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.InvestmentAmounttTextBox);
            this.Controls.Add(this.DisplayGroupBox);
            this.Controls.Add(this.InvestmentAmountLabel);
            this.Controls.Add(this.ButtonGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Welcome to Invest4U";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ButtonGroupBox.ResumeLayout(false);
            this.ProceedGroupBox.ResumeLayout(false);
            this.ProceedGroupBox.PerformLayout();
            this.DisplayGroupBox.ResumeLayout(false);
            this.DisplayGroupBox.PerformLayout();
            this.SearchGroupBox.ResumeLayout(false);
            this.SearchGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.SummaryGroupBox.ResumeLayout(false);
            this.SummaryGroupBox.PerformLayout();
            this.ProceedGroupBoxDetails.ResumeLayout(false);
            this.ProceedGroupBoxDetails.PerformLayout();
            this.LoginGroupBox.ResumeLayout(false);
            this.LoginGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.GroupBox ButtonGroupBox;
        private System.Windows.Forms.Button DisplayButton;
        private System.Windows.Forms.Label InvestmentAmountLabel;
        private System.Windows.Forms.TextBox InvestmentAmounttTextBox;
        private System.Windows.Forms.GroupBox DisplayGroupBox;
        private System.Windows.Forms.Label TermTenLabel;
        private System.Windows.Forms.Label TermFiveLabel;
        private System.Windows.Forms.Label TermThreeLabel;
        private System.Windows.Forms.Label TermOneLabel;
        private System.Windows.Forms.Label TenYearLabel;
        private System.Windows.Forms.Label FiveYearLabel;
        private System.Windows.Forms.Label ThreeYearLabel;
        private System.Windows.Forms.Label OneYearLabel;
        private System.Windows.Forms.RadioButton TenYearRadioButton;
        private System.Windows.Forms.RadioButton FiveYearsRadioButton;
        private System.Windows.Forms.RadioButton ThreeYearRadioButton;
        private System.Windows.Forms.RadioButton OneYearRadioButton;
        private System.Windows.Forms.Label MoreThan;
        private System.Windows.Forms.Label Upto;
        private System.Windows.Forms.Label Term;
        private System.Windows.Forms.Button Proceed;
        private System.Windows.Forms.GroupBox ProceedGroupBox;
        private System.Windows.Forms.Label DateDisplayLabel;
        private System.Windows.Forms.Label TransactionIDDisplay;
        private System.Windows.Forms.TextBox TelephoneNoTextBox;
        private System.Windows.Forms.TextBox EmailIDTextBox;
        private System.Windows.Forms.Label TelephoneNoLabel;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.TextBox LastNameTextbox;
        private System.Windows.Forms.TextBox FirstNameTextbox;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label Trans;
        private System.Windows.Forms.Label InvestmentFutureValue;
        private System.Windows.Forms.Button SummaryButton;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.GroupBox SearchGroupBox;
        private System.Windows.Forms.ListBox SearchListBox;
        private System.Windows.Forms.Button SearchFiltersButton;
        private System.Windows.Forms.Label FutureValue;
        private System.Windows.Forms.Label EnterPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SearchByDateTextBox;
        private System.Windows.Forms.ListBox SummaryListBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox SummaryGroupBox;
        private System.Windows.Forms.Label InvestedAmountLabel;
        private System.Windows.Forms.Label NoOfTransDisplayLabel;
        private System.Windows.Forms.Label NoOfTrans;
        private System.Windows.Forms.Label TotalInvAmountLabel;
        private System.Windows.Forms.Label AverageInvestedAmountLabel;
        private System.Windows.Forms.Label AverageInvestedDisplayLabel;
        private System.Windows.Forms.Label AverageTermValue;
        private System.Windows.Forms.Label AverageTenure;
        private System.Windows.Forms.Label IntLabel;
        private System.Windows.Forms.Label TotalInterestLabel;
        private System.Windows.Forms.GroupBox ProceedGroupBoxDetails;
        private System.Windows.Forms.Label TransactionIDDisplayLabel;
        private System.Windows.Forms.Label TransID;
        private System.Windows.Forms.Label CurrentDateDisplayLabel;
        private System.Windows.Forms.Label CurrentDateLabel;
        private System.Windows.Forms.Label InvestmentFutureValueDisplayLabel;
        private System.Windows.Forms.Label InvestmentFutureValueLabel;
        private System.Windows.Forms.Label DisplayText;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label EmailIDLabel;
        private System.Windows.Forms.TextBox LastNTextbox;
        private System.Windows.Forms.TextBox FirstNTextbox;
        private System.Windows.Forms.TextBox TeleTextbox;
        private System.Windows.Forms.TextBox EmailTextbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.GroupBox LoginGroupBox;
        private System.Windows.Forms.RadioButton IDSearchRadioButton;
        private System.Windows.Forms.RadioButton SearchbyEmailRadioButton;
        private System.Windows.Forms.RadioButton SearchbyDateRadioButton;
        private System.Windows.Forms.Label TransactionList;
        private System.Windows.Forms.ToolTip ExitToolTip;
        private System.Windows.Forms.ToolTip ClearToolTip;
        private System.Windows.Forms.ToolTip LoginToolTip;
        private System.Windows.Forms.ToolTip SearchToolTip;
        private System.Windows.Forms.ToolTip SummaryToolTip;
        private System.Windows.Forms.ToolTip LoginTool;
        private System.Windows.Forms.ToolTip SubmitToolTip;
        private System.Windows.Forms.ToolTip ProceedToolTip;
        private System.Windows.Forms.ToolTip DisplayToolTip;
    }
}

